<?php
/**
 * Astra functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Define Constants
 */
define( 'ASTRA_THEME_VERSION', '4.13.2' );
define( 'ASTRA_THEME_SETTINGS', 'astra-settings' );
define( 'ASTRA_THEME_DIR', trailingslashit( get_template_directory() ) );
define( 'ASTRA_THEME_URI', trailingslashit( esc_url( get_template_directory_uri() ) ) );
define( 'ASTRA_THEME_ORG_VERSION', file_exists( ASTRA_THEME_DIR . 'inc/w-org-version.php' ) );

/**
 * Minimum Version requirement of the Astra Pro addon.
 * This constant will be used to display the notice asking user to update the Astra addon to the version defined below.
 */
define( 'ASTRA_EXT_MIN_VER', '4.12.0' );

/**
 * Load in-house compatibility.
 */
if ( ASTRA_THEME_ORG_VERSION ) {
	require_once ASTRA_THEME_DIR . 'inc/w-org-version.php';
}

/**
 * Setup helper functions of Astra.
 */
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-theme-options.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-theme-strings.php';
require_once ASTRA_THEME_DIR . 'inc/core/common-functions.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-icons.php';

define( 'ASTRA_WEBSITE_BASE_URL', 'https://wpastra.com' );

/**
 * Update theme
 */
require_once ASTRA_THEME_DIR . 'inc/theme-update/astra-update-functions.php';
require_once ASTRA_THEME_DIR . 'inc/theme-update/class-astra-theme-background-updater.php';

/**
 * Fonts Files
 */
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-font-families.php';
if ( is_admin() ) {
	require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-fonts-data.php';
}

require_once ASTRA_THEME_DIR . 'inc/lib/webfont/class-astra-webfont-loader.php';
require_once ASTRA_THEME_DIR . 'inc/lib/docs/class-astra-docs-loader.php';
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-fonts.php';

require_once ASTRA_THEME_DIR . 'inc/dynamic-css/custom-menu-old-header.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/container-layouts.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/astra-icons.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-walker-page.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-enqueue-scripts.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-gutenberg-editor-css.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-wp-editor-css.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-command-palette.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/block-editor-compatibility.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/inline-on-mobile.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/content-background.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/dark-mode.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-dynamic-css.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-global-palette.php';

// Enable NPS Survey only if the starter templates version is < 4.3.7 or > 4.4.4 to prevent fatal error.
if ( ! defined( 'ASTRA_SITES_VER' ) || version_compare( ASTRA_SITES_VER, '4.3.7', '<' ) || version_compare( ASTRA_SITES_VER, '4.4.4', '>' ) ) {
	// NPS Survey Integration
	require_once ASTRA_THEME_DIR . 'inc/lib/class-astra-nps-notice.php';
	require_once ASTRA_THEME_DIR . 'inc/lib/class-astra-nps-survey.php';
}

/**
 * Custom template tags for this theme.
 */
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-attr.php';
require_once ASTRA_THEME_DIR . 'inc/template-tags.php';

require_once ASTRA_THEME_DIR . 'inc/widgets.php';
require_once ASTRA_THEME_DIR . 'inc/core/theme-hooks.php';
require_once ASTRA_THEME_DIR . 'inc/admin-functions.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-memory-limit-notice.php';
require_once ASTRA_THEME_DIR . 'inc/core/sidebar-manager.php';

/**
 * Markup Functions
 */
require_once ASTRA_THEME_DIR . 'inc/markup-extras.php';
require_once ASTRA_THEME_DIR . 'inc/extras.php';
require_once ASTRA_THEME_DIR . 'inc/blog/blog-config.php';
require_once ASTRA_THEME_DIR . 'inc/blog/blog.php';
require_once ASTRA_THEME_DIR . 'inc/blog/single-blog.php';

/**
 * Markup Files
 */
require_once ASTRA_THEME_DIR . 'inc/template-parts.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-loop.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-mobile-header.php';

/**
 * Functions and definitions.
 */
require_once ASTRA_THEME_DIR . 'inc/class-astra-after-setup-theme.php';

// Required files.
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-admin-helper.php';

require_once ASTRA_THEME_DIR . 'inc/schema/class-astra-schema.php';

/* Setup API */
require_once ASTRA_THEME_DIR . 'admin/includes/class-astra-learn.php';
require_once ASTRA_THEME_DIR . 'admin/includes/class-astra-api-init.php';

if ( is_admin() ) {
	/**
	 * Admin Menu Settings
	 */
	require_once ASTRA_THEME_DIR . 'inc/core/class-astra-admin-settings.php';
	require_once ASTRA_THEME_DIR . 'admin/class-astra-admin-loader.php';
	require_once ASTRA_THEME_DIR . 'inc/lib/astra-notices/class-bsf-admin-notices.php';
}

/**
 * BSF Analytics.
 */
require_once ASTRA_THEME_DIR . 'admin/class-astra-bsf-analytics.php';

/**
 * Metabox additions.
 */
require_once ASTRA_THEME_DIR . 'inc/metabox/class-astra-meta-boxes.php';
require_once ASTRA_THEME_DIR . 'inc/metabox/class-astra-meta-box-operations.php';
require_once ASTRA_THEME_DIR . 'inc/metabox/class-astra-elementor-editor-settings.php';

/**
 * Customizer additions.
 */
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-customizer.php';

/**
 * Astra Modules.
 */
require_once ASTRA_THEME_DIR . 'inc/modules/posts-structures/class-astra-post-structures.php';
require_once ASTRA_THEME_DIR . 'inc/modules/related-posts/class-astra-related-posts.php';

/**
 * Compatibility
 */
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-gutenberg.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-jetpack.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/woocommerce/class-astra-woocommerce.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/edd/class-astra-edd.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/lifterlms/class-astra-lifterlms.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/learndash/class-astra-learndash.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-beaver-builder.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-bb-ultimate-addon.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-contact-form-7.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-visual-composer.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-site-origin.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-gravity-forms.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-bne-flyout.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-ubermeu.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-divi-builder.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-amp.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-yoast-seo.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/surecart/class-astra-surecart.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-starter-content.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-buddypress.php';
require_once ASTRA_THEME_DIR . 'inc/addons/transparent-header/class-astra-ext-transparent-header.php';
require_once ASTRA_THEME_DIR . 'inc/addons/breadcrumbs/class-astra-breadcrumbs.php';
require_once ASTRA_THEME_DIR . 'inc/addons/scroll-to-top/class-astra-scroll-to-top.php';
require_once ASTRA_THEME_DIR . 'inc/addons/heading-colors/class-astra-heading-colors.php';
require_once ASTRA_THEME_DIR . 'inc/builder/class-astra-builder-loader.php';

// Elementor Compatibility requires PHP 5.4 for namespaces.
if ( version_compare( PHP_VERSION, '5.4', '>=' ) ) {
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-elementor.php';
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-elementor-pro.php';
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-web-stories.php';
}

// Beaver Themer compatibility requires PHP 5.3 for anonymous functions.
if ( version_compare( PHP_VERSION, '5.3', '>=' ) ) {
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-beaver-themer.php';
}

require_once ASTRA_THEME_DIR . 'inc/core/markup/class-astra-markup.php';

/**
 * Abilities API integration.
 */
require_once ASTRA_THEME_DIR . 'inc/abilities/bootstrap.php';

/**
 * Load deprecated functions
 */
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-filters.php';
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-hooks.php';
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-functions.php';
/**
 * ============================================================
 * MediCare+ — functions.php Snippets
 * ============================================================
 */

/* ============================================================
   1. ENQUEUE CSS & JS
   ============================================================ */
add_action('wp_enqueue_scripts', 'mc_enqueue_assets');
function mc_enqueue_assets() {

    // Only load MediCare+ styles on the front page
    if (!is_front_page()) return;

    // Font Awesome (icons)
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
        [],
        '6.5.0'
    );

    // Google Font: Poppins
    wp_enqueue_style(
        'mc-poppins',
        'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap',
        [],
        null
    );

    // MediCare+ main stylesheet
    wp_enqueue_style(
        'mc-custom-style',
        get_stylesheet_directory_uri() . '/assets/css/medicare-custom.css',
        ['font-awesome', 'mc-poppins'],
        '1.0.0'
    );

    // WooCommerce AJAX add-to-cart
    wp_enqueue_script('wc-add-to-cart');

    // MediCare+ homepage JavaScript
    wp_enqueue_script(
        'mc-custom-js',
        get_stylesheet_directory_uri() . '/assets/js/medicare-custom.js',
        ['jquery'],   
        '1.0.0',
        true          
    );

    // Pass PHP variables to JavaScript
    wp_localize_script('mc-custom-js', 'mc_vars', [
        'cart_url'        => wc_get_cart_url(),
        'shop_url'        => wc_get_page_permalink('shop'),
        'ajax_url'        => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('mc_ajax_nonce'),
        'whatsapp'        => get_option('mc_whatsapp_number', '919876543210'),
        'currency_symbol'=> get_woocommerce_currency_symbol(),
    ]);
}


/* ============================================================
   2. ASTRA THEME — REMOVE SIDEBAR & SET FULL-WIDTH LAYOUT
   ============================================================ */
add_filter('astra_page_layout', 'mc_astra_full_width_front');
function mc_astra_full_width_front($layout) {
    if (is_front_page()) {
        return 'no-sidebar'; 
    }
    return $layout;
}

add_action('wp_body_open', 'mc_remove_astra_content_padding');
function mc_remove_astra_content_padding() {
    if (is_front_page()) {
        add_filter('astra_content_top_padding', '__return_zero');
        add_filter('astra_content_bottom_padding', '__return_zero');
    }
}


/* ============================================================
   3. REUSABLE PRODUCT CARD RENDER FUNCTION
   ============================================================ */
if (!function_exists('mc_render_product_cards')) :
function mc_render_product_cards(array $products) {
    if (empty($products)) {
        echo '<p style="color:#6B7280;font-size:0.8rem;padding:10px 0;">No products found yet.</p>';
        return;
    }
    foreach ($products as $product) :
        $price     = $product->get_price();
        $reg_price = $product->get_regular_price();
        $sale_pct  = ($reg_price && $price < $reg_price)
                     ? round((($reg_price - $price) / $reg_price) * 100) . '% OFF'
                     : '';
        $img       = wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail');
        $rating    = $product->get_average_rating();
        $count     = $product->get_rating_count();
        ?>
        <div class="mc-prod-card" onclick="window.location='<?php echo esc_url($product->get_permalink()); ?>'">
            <?php if ($sale_pct) : ?>
                <div class="mc-prod-badge"><?php echo esc_html($sale_pct); ?></div>
            <?php endif; ?>

            <div class="mc-prod-img">
                <?php if ($img) : ?>
                    <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" loading="lazy"/>
                <?php else : ?>
                    <div class="mc-prod-emoji">💊</div>
                <?php endif; ?>
            </div>

            <div class="mc-prod-name"><?php echo esc_html($product->get_name()); ?></div>
            <div class="mc-prod-sub"><?php echo esc_html($product->get_short_description()); ?></div>

            <?php if ($rating) : ?>
            <div class="mc-prod-stars">
                <?php for ($i = 1; $i <= 5; $i++) :
                    $cls = ($i <= floor($rating)) ? 'fas fa-star'
                         : ($i == ceil($rating) && ($rating - floor($rating)) >= 0.5 ? 'fas fa-star-half-stroke' : 'far fa-star');
                ?>
                    <i class="<?php echo $cls; ?>"></i>
                <?php endfor; ?>
                <span>(<?php echo esc_html($count); ?>)</span>
            </div>
            <?php endif; ?>

            <div class="mc-prod-price">
                <span class="mc-price"><?php echo wc_price($price); ?></span>
                <?php if ($reg_price && $reg_price > $price) : ?>
                    <span class="mc-old"><?php echo wc_price($reg_price); ?></span>
                <?php endif; ?>
            </div>

            <a href="<?php echo esc_url(add_query_arg(['add-to-cart' => $product->get_id()], wc_get_cart_url())); ?>"
               class="mc-btn-add"
               onclick="event.stopPropagation();"
               data-product_id="<?php echo esc_attr($product->get_id()); ?>"
               aria-label="Add <?php echo esc_attr($product->get_name()); ?> to cart"
               rel="nofollow">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </a>
        </div>
        <?php
    endforeach;
}
endif;


/* ============================================================
   4. PRESCRIPTION UPLOAD HANDLER
   ============================================================ */
add_action('admin_post_mc_prescription_upload', 'mc_handle_prescription_upload');
add_action('admin_post_nopriv_mc_prescription_upload', 'mc_handle_prescription_upload');

function mc_handle_prescription_upload() {
    if (!isset($_POST['mc_rx_nonce']) || !wp_verify_nonce($_POST['mc_rx_nonce'], 'mc_rx_upload')) {
        wp_die('Security check failed. Please go back and try again.');
    }

    if (!isset($_FILES['prescription']) || $_FILES['prescription']['error'] !== UPLOAD_ERR_OK) {
        wp_safe_redirect(add_query_arg('rx_status', 'error', wp_get_referer()));
        exit;
    }

    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!in_array($_FILES['prescription']['type'], $allowed_types)) {
        wp_safe_redirect(add_query_arg('rx_status', 'invalid_type', wp_get_referer()));
        exit;
    }

    if ($_FILES['prescription']['size'] > 5 * 1024 * 1024) {
        wp_safe_redirect(add_query_arg('rx_status', 'too_large', wp_get_referer()));
        exit;
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $attachment_id = media_handle_upload('prescription', 0);

    if (is_wp_error($attachment_id)) {
        wp_safe_redirect(add_query_arg('rx_status', 'upload_error', wp_get_referer()));
        exit;
    }

    $phone = sanitize_text_field($_POST['mc_rx_phone'] ?? '');
    update_post_meta($attachment_id, 'mc_rx_phone', $phone);
    update_post_meta($attachment_id, 'mc_rx_submitted', current_time('mysql'));

    $admin_email = get_option('admin_email');
    $file_url    = wp_get_attachment_url($attachment_id);
    wp_mail(
        $admin_email,
        'New Prescription Uploaded — MediCare+',
        "A new prescription was uploaded.\n\nPhone: {$phone}\nFile: {$file_url}\nTime: " . current_time('mysql'),
        ['Content-Type: text/plain; charset=UTF-8']
    );

    wp_safe_redirect(add_query_arg('rx_status', 'success', wp_get_referer()));
    exit;
}

add_action('wp_footer', 'mc_rx_upload_notice');
function mc_rx_upload_notice() {
    if (!isset($_GET['rx_status'])) return;
    $messages = [
        'success'      => ['✅ Prescription uploaded! We will contact you within 30 minutes.', 'success'],
        'error'        => ['❌ Upload failed. Please try again.', 'error'],
        'invalid_type' => ['❌ Only JPG, PNG, PDF files allowed.', 'error'],
        'too_large'    => ['❌ File too large. Max size is 5MB.', 'error'],
        'upload_error' => ['❌ Server error during upload. Please try again.', 'error'],
    ];
    $status = sanitize_key($_GET['rx_status']);
    if (!isset($messages[$status])) return;
    [$msg, $type] = $messages[$status];
    echo "<script>document.addEventListener('DOMContentLoaded',function(){mcpShowToast(" . json_encode($msg) . ",'" . $type . "');});</script>";
}


/* ============================================================
   5. SIMPLE OPTIONS PAGE (WP Admin → Settings → MediCare Options)
   ============================================================ */
add_action('admin_menu', 'mc_add_settings_page');
function mc_add_settings_page() {
    add_options_page(
        'MediCare+ Options',
        'MediCare+ Options',
        'manage_options',
        'medicare-options',
        'mc_render_settings_page'
    );
}

add_action('admin_init', 'mc_register_settings');
function mc_register_settings() {
    $options = [
        'mc_whatsapp_number' => 'WhatsApp Number',
        'mc_support_phone'   => 'Support Phone',
        'mc_helpline'        => 'Helpline Text',
        'mc_hero_subtitle'   => 'Hero Section Subtitle Text',
    ];
    foreach ($options as $key => $label) {
        register_setting('mc_options_group', $key, ['sanitize_callback' => 'sanitize_text_field']);
    }
}

function mc_render_settings_page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap">
        <h1>MediCare+ Options</h1>
        <form method="post" action="options.php">
            <?php settings_fields('mc_options_group'); ?>
            <table class="form-table">
                <tr>
                    <th>WhatsApp Number</th>
                    <td>
                        <input type="text" name="mc_whatsapp_number" value="<?php echo esc_attr(get_option('mc_whatsapp_number', '919876543210')); ?>" class="regular-text" placeholder="919876543210"/>
                        <p class="description">With country code, no + sign.</p>
                    </td>
                </tr>
                <tr>
                    <th>Support Phone</th>
                    <td>
                        <input type="text" name="mc_support_phone" value="<?php echo esc_attr(get_option('mc_support_phone', '18001234567')); ?>" class="regular-text"/>
                    </td>
                </tr>
                <tr>
                    <th>Helpline Text</th>
                    <td>
                        <input type="text" name="mc_helpline" value="<?php echo esc_attr(get_option('mc_helpline', '📞 Helpline: 1800-123-4567 (Free)')); ?>" class="regular-text"/>
                    </td>
                </tr>
                <tr>
                    <th>Hero Subtitle</th>
                    <td>
                        <input type="text" name="mc_hero_subtitle" value="<?php echo esc_attr(get_option('mc_hero_subtitle', 'Order medicines online from trusted pharmacy. 100% genuine products.')); ?>" class="large-text"/>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save MediCare+ Settings'); ?>
        </form>
    </div>
    <?php
}


/* ============================================================
   6. WOOCOMMERCE AJAX ADD-TO-CART FEEDBACK
   ============================================================ */
add_action('wp_footer', 'mc_wc_ajax_cart_feedback');
function mc_wc_ajax_cart_feedback() {
    if (!is_front_page()) return;
    ?>
    <script>
    jQuery(document).on('added_to_cart', function(e, fragments, cart_hash, $button) {
        var name = $button.closest('.mc-prod-card').find('.mc-prod-name').text() || 'Product';
        mcpShowToast(name + ' added to cart! 🛒', 'success');
    });
    </script>
    <?php
}
// ==============================================================
// MEDICARE APP - AJAX ORDER PROCESSOR
// ==============================================================
add_action('wp_ajax_mc_place_order',        'mc_ajax_place_order');
add_action('wp_ajax_nopriv_mc_place_order', 'mc_ajax_place_order');

function mc_ajax_place_order() {
    // 1. Security Check
    if (!check_ajax_referer('mc_order_nonce', 'security', false)) {
        wp_send_json_error(['message' => 'Security check failed. Please refresh the page.']);
        return;
    }

    // 2. WooCommerce Check
    if (!class_exists('WooCommerce')) {
        wp_send_json_error(['message' => 'WooCommerce is not active.']);
        return;
    }

    // 3. Get Data from App Layout
    $cart_data = json_decode(stripslashes($_POST['cart_data']), true);
    $name      = sanitize_text_field($_POST['name']);
    $phone     = sanitize_text_field($_POST['phone']);
    $address   = sanitize_text_field($_POST['address']);

    // 4. Validate Data
    if (empty($cart_data) || empty($name) || empty($phone) || empty($address)) {
        wp_send_json_error(['message' => 'Please fill all details (Name, Phone, Address).']);
        return;
    }

    try {
        // 5. Create Real WooCommerce Order
        $order = wc_create_order();

        // 6. Add Products to Order
        foreach ($cart_data as $item) {
            $product_id = intval($item['id']);
            $quantity   = intval($item['qty']);
            $product    = wc_get_product($product_id);
            
            if ($product) {
                $order->add_product($product, $quantity);
            }
        }

        // 7. Set Customer Address
        $address_data = [
            'first_name' => $name,
            'phone'      => $phone,
            'address_1'  => $address,
            'city'       => get_option('woocommerce_store_city', 'Peshawar'),
            'country'    => 'PK'
        ];
        $order->set_address($address_data, 'billing');
        $order->set_address($address_data, 'shipping');

        // 8. Set Payment to COD (Cash on Delivery)
        $order->set_payment_method('cod');
        $order->set_payment_method_title('Cash on Delivery');

        // 9. Calculate Totals and Save
        $order->calculate_totals();
        $order->update_status('processing', 'Order placed via Custom App Layout.');

        // 10. Send Success Response back to App
        wp_send_json_success([
            'order_id' => $order->get_id(),
            'message'  => 'Order placed successfully!'
        ]);

    } catch (Exception $e) {
        // Handle Errors (e.g. Out of stock)
        wp_send_json_error(['message' => 'Failed to create order: ' . $e->getMessage()]);
    }
}