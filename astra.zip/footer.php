</main>
</div><!-- /mcp-page -->

<!-- ═══════════════════════════════════════════════════════
     MediCare+ FOOTER — Embedded CSS + JS
     Clean · Fast · Premium Medical E-Commerce
═══════════════════════════════════════════════════════ -->

<style>
/* ── Footer CSS Variables (inherits header vars if loaded) ── */
:root {
  --ft-bg:          #0A1628;
  --ft-bg2:         #0F1E38;
  --ft-bg3:         #162445;
  --ft-border:      rgba(255,255,255,.08);
  --ft-text:        rgba(255,255,255,.75);
  --ft-text2:       rgba(255,255,255,.45);
  --ft-white:       #ffffff;
  --ft-primary:     #1E88E5;
  --ft-accent:      #00ACC1;
  --ft-green:       #43A047;
  --ft-yellow:      #FFD54F;
  --ft-red:         #EF5350;
  --ft-radius:      12px;
  --ft-radius-sm:   8px;
  --ft-transition:  .22s cubic-bezier(.4,0,.2,1);
  --ft-font:        'Nunito', sans-serif;
  --ft-font2:       'Poppins', sans-serif;
}

/* ── Back to Top Button ── */
.ft-back-top {
  position: fixed; bottom: 28px; right: 22px;
  width: 46px; height: 46px; border-radius: 50%;
  background: linear-gradient(135deg, var(--ft-primary), var(--ft-accent));
  color: #fff; border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem; box-shadow: 0 6px 20px rgba(30,136,229,.4);
  opacity: 0; transform: translateY(16px);
  transition: opacity .3s ease, transform .3s ease, box-shadow .2s;
  z-index: 700; pointer-events: none;
}
.ft-back-top.show { opacity: 1; transform: translateY(0); pointer-events: all; }
.ft-back-top:hover { box-shadow: 0 8px 28px rgba(30,136,229,.55); transform: translateY(-2px); }

/* ── Newsletter Strip ── */
.ft-newsletter {
  background: linear-gradient(135deg, var(--ft-primary) 0%, #0D47A1 50%, var(--ft-accent) 100%);
  padding: 40px 20px;
  position: relative; overflow: hidden;
}
.ft-newsletter::before {
  content: '';
  position: absolute; inset: 0;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.04'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
.ft-nl-inner {
  max-width: 1380px; margin: 0 auto;
  display: flex; align-items: center; gap: 40px;
  flex-wrap: wrap; position: relative;
}
.ft-nl-text { flex: 1; min-width: 240px; }
.ft-nl-title {
  font-family: var(--ft-font2); font-size: 1.4rem;
  font-weight: 700; color: #fff; margin-bottom: 4px;
}
.ft-nl-title span { color: var(--ft-yellow); }
.ft-nl-sub { font-size: .87rem; color: rgba(255,255,255,.8); font-family: var(--ft-font); }
.ft-nl-form {
  flex: 1; min-width: 280px;
  display: flex; gap: 0;
  background: rgba(255,255,255,.12);
  border: 1.5px solid rgba(255,255,255,.25);
  border-radius: 50px; padding: 5px;
  backdrop-filter: blur(8px);
  max-width: 500px;
}
.ft-nl-input {
  flex: 1; border: none; background: transparent;
  font-family: var(--ft-font); font-size: .9rem;
  color: #fff; padding: 0 16px; outline: none;
}
.ft-nl-input::placeholder { color: rgba(255,255,255,.55); }
.ft-nl-btn {
  background: var(--ft-yellow); color: #0A1628;
  border: none; border-radius: 50px;
  padding: 11px 24px; font-family: var(--ft-font2);
  font-size: .85rem; font-weight: 800; cursor: pointer;
  white-space: nowrap; flex-shrink: 0;
  transition: filter var(--ft-transition), transform var(--ft-transition);
}
.ft-nl-btn:hover { filter: brightness(1.08); transform: scale(1.02); }
.ft-nl-trust {
  display: flex; align-items: center; gap: 16px;
  flex-wrap: wrap; margin-top: 10px;
}
.ft-nl-trust span {
  display: flex; align-items: center; gap: 5px;
  font-size: .75rem; color: rgba(255,255,255,.7);
  font-family: var(--ft-font); font-weight: 600;
}
.ft-nl-trust i { color: var(--ft-yellow); font-size: .8rem; }

/* ── Trust Badges Bar ── */
.ft-trust-bar {
  background: var(--ft-bg2);
  border-top: 1px solid var(--ft-border);
  border-bottom: 1px solid var(--ft-border);
  padding: 0 20px;
}
.ft-trust-inner {
  max-width: 1380px; margin: 0 auto;
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 0; divide-x: 1px solid var(--ft-border);
}
.ft-trust-item {
  display: flex; align-items: center; gap: 14px;
  padding: 20px 24px;
  border-right: 1px solid var(--ft-border);
  transition: background var(--ft-transition);
}
.ft-trust-item:last-child { border-right: none; }
.ft-trust-item:hover { background: rgba(255,255,255,.03); }
.ft-trust-icon {
  width: 44px; height: 44px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.25rem; flex-shrink: 0;
}
.ft-trust-content {}
.ft-trust-title {
  font-family: var(--ft-font2); font-size: .85rem;
  font-weight: 700; color: var(--ft-white); margin-bottom: 2px;
}
.ft-trust-sub {
  font-size: .74rem; color: var(--ft-text2);
  font-family: var(--ft-font);
}

/* ── Main Footer Body ── */
.mcp-footer {
  background: var(--ft-bg);
  padding: 60px 20px 0;
  font-family: var(--ft-font);
}
.ft-main-inner {
  max-width: 1380px; margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr 1.4fr;
  gap: 48px;
}

/* ── Brand Column ── */
.ft-brand {}
.ft-logo {
  display: flex; align-items: center; gap: 10px;
  text-decoration: none; margin-bottom: 16px;
}
.ft-logo-icon {
  width: 42px; height: 42px; border-radius: 11px;
  background: linear-gradient(135deg, var(--ft-primary), var(--ft-accent));
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 1.15rem;
  box-shadow: 0 4px 14px rgba(30,136,229,.35);
}
.ft-logo-text {
  font-family: var(--ft-font2); font-size: 1.3rem;
  font-weight: 700; color: var(--ft-white);
}
.ft-logo-plus { color: var(--ft-accent); }
.ft-brand-desc {
  font-size: .84rem; line-height: 1.7;
  color: var(--ft-text); margin-bottom: 20px;
  max-width: 280px;
}
.ft-license-badge {
  display: inline-flex; align-items: center; gap: 7px;
  background: rgba(67,160,71,.12);
  border: 1px solid rgba(67,160,71,.25);
  border-radius: 50px; padding: 6px 14px;
  font-size: .74rem; font-weight: 700;
  color: #81C784; margin-bottom: 18px;
}
.ft-license-badge i { color: var(--ft-green); }

/* Social Icons */
.ft-social { display: flex; gap: 8px; margin-bottom: 22px; }
.ft-social-btn {
  width: 36px; height: 36px; border-radius: 9px;
  background: rgba(255,255,255,.07); border: 1px solid var(--ft-border);
  color: var(--ft-text); font-size: .9rem;
  display: flex; align-items: center; justify-content: center;
  text-decoration: none; cursor: pointer;
  transition: background var(--ft-transition), color var(--ft-transition), transform var(--ft-transition);
}
.ft-social-btn:hover { transform: translateY(-3px); color: #fff; }
.ft-social-btn.fb:hover  { background: #1877F2; border-color: #1877F2; }
.ft-social-btn.ig:hover  { background: linear-gradient(135deg,#833AB4,#FD1D1D,#F77737); border-color: transparent; }
.ft-social-btn.tw:hover  { background: #1DA1F2; border-color: #1DA1F2; }
.ft-social-btn.wa:hover  { background: #25D366; border-color: #25D366; }
.ft-social-btn.yt:hover  { background: #FF0000; border-color: #FF0000; }

/* App Download */
.ft-app-title {
  font-size: .72rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: .07em; color: var(--ft-text2); margin-bottom: 10px;
}
.ft-app-btns { display: flex; gap: 8px; flex-wrap: wrap; }
.ft-app-btn {
  display: flex; align-items: center; gap: 8px;
  background: rgba(255,255,255,.07); border: 1.5px solid rgba(255,255,255,.14);
  border-radius: var(--ft-radius-sm); padding: 8px 14px;
  text-decoration: none; color: var(--ft-white);
  transition: background var(--ft-transition), border-color var(--ft-transition);
}
.ft-app-btn:hover { background: rgba(255,255,255,.13); border-color: rgba(255,255,255,.28); }
.ft-app-btn i { font-size: 1.3rem; }
.ft-app-btn-text { display: flex; flex-direction: column; line-height: 1.2; }
.ft-app-btn-sub  { font-size: .62rem; color: var(--ft-text2); font-weight: 600; }
.ft-app-btn-main { font-size: .82rem; font-weight: 800; }

/* ── Link Columns ── */
.ft-col-title {
  font-family: var(--ft-font2); font-size: .88rem;
  font-weight: 700; color: var(--ft-white);
  margin-bottom: 18px; padding-bottom: 10px;
  border-bottom: 2px solid var(--ft-primary);
  display: inline-block;
}
.ft-links { list-style: none; display: flex; flex-direction: column; gap: 2px; }
.ft-links li a {
  display: flex; align-items: center; gap: 7px;
  font-size: .83rem; color: var(--ft-text);
  text-decoration: none; padding: 5px 0;
  transition: color var(--ft-transition), gap var(--ft-transition);
}
.ft-links li a i {
  font-size: .6rem; color: var(--ft-primary);
  transition: transform var(--ft-transition);
}
.ft-links li a:hover { color: var(--ft-white); gap: 10px; }
.ft-links li a:hover i { transform: translateX(2px); }

/* ── Contact Column ── */
.ft-contact-list { display: flex; flex-direction: column; gap: 14px; }
.ft-contact-item {
  display: flex; align-items: flex-start; gap: 12px;
}
.ft-contact-icon {
  width: 34px; height: 34px; border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: .9rem; flex-shrink: 0;
}
.ft-contact-text {}
.ft-contact-label {
  font-size: .68rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: .05em; color: var(--ft-text2); margin-bottom: 1px;
}
.ft-contact-val {
  font-size: .83rem; color: var(--ft-text);
  font-weight: 600; line-height: 1.4;
}
.ft-contact-val a { color: inherit; text-decoration: none; }
.ft-contact-val a:hover { color: var(--ft-white); }

/* Timing Badge */
.ft-timing {
  display: flex; align-items: center; gap: 8px;
  background: rgba(255,213,79,.08);
  border: 1px solid rgba(255,213,79,.2);
  border-radius: var(--ft-radius-sm); padding: 8px 12px;
  margin-top: 14px;
}
.ft-timing i { color: var(--ft-yellow); font-size: .9rem; }
.ft-timing-text {}
.ft-timing-main { font-size: .8rem; font-weight: 700; color: var(--ft-yellow); }
.ft-timing-sub  { font-size: .72rem; color: var(--ft-text2); }

/* ── Divider ── */
.ft-divider {
  max-width: 1380px; margin: 48px auto 0;
  border: none; border-top: 1px solid var(--ft-border);
}

/* ── Payment Methods ── */
.ft-payments {
  max-width: 1380px; margin: 0 auto;
  padding: 24px 20px;
  display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap; gap: 16px;
}
.ft-pay-label {
  font-size: .75rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: .06em; color: var(--ft-text2);
  flex-shrink: 0;
}
.ft-pay-icons {
  display: flex; align-items: center; gap: 6px; flex-wrap: wrap;
}
.ft-pay-badge {
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 6px; padding: 5px 11px;
  font-size: .72rem; font-weight: 800;
  color: var(--ft-text); letter-spacing: .02em;
  transition: background var(--ft-transition);
}
.ft-pay-badge:hover { background: rgba(255,255,255,.14); }
.ft-pay-badge.visa    { color: #1A1F71; background: #fff; border-color: #e0e0e0; }
.ft-pay-badge.mc      { background: #fff; border-color: #e0e0e0; }
.ft-pay-badge.upi     { color: #4CAF50; background: rgba(76,175,80,.1); border-color: rgba(76,175,80,.25); }
.ft-pay-badge.paytm   { color: #002970; background: #00BAF2; border-color: transparent; }
.ft-pay-badge.cod     { color: var(--ft-yellow); background: rgba(255,213,79,.1); border-color: rgba(255,213,79,.25); }
.ft-ssl-badge {
  display: flex; align-items: center; gap: 6px;
  background: rgba(67,160,71,.1); border: 1px solid rgba(67,160,71,.25);
  border-radius: 6px; padding: 6px 12px;
  font-size: .74rem; font-weight: 700; color: #81C784;
}
.ft-ssl-badge i { font-size: .85rem; }

/* ── Bottom Bar ── */
.ft-bottom {
  background: var(--ft-bg2);
  border-top: 1px solid var(--ft-border);
}
.ft-bottom-inner {
  max-width: 1380px; margin: 0 auto;
  padding: 18px 20px;
  display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap; gap: 12px;
}
.ft-copy {
  font-size: .78rem; color: var(--ft-text2); font-weight: 600;
}
.ft-copy span { color: var(--ft-text); }
.ft-bottom-links {
  display: flex; align-items: center; gap: 20px; flex-wrap: wrap;
}
.ft-bottom-links a {
  font-size: .77rem; color: var(--ft-text2);
  text-decoration: none; font-weight: 600;
  transition: color var(--ft-transition);
}
.ft-bottom-links a:hover { color: var(--ft-white); }
.ft-bottom-links span { color: var(--ft-border); font-size: .8rem; }

/* ── Cookie Banner ── */
.ft-cookie {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: var(--ft-bg2);
  border-top: 1px solid var(--ft-border);
  padding: 14px 20px; z-index: 800;
  display: flex; align-items: center;
  justify-content: space-between; gap: 16px;
  flex-wrap: wrap;
  transform: translateY(100%);
  transition: transform .4s cubic-bezier(.4,0,.2,1);
  box-shadow: 0 -4px 24px rgba(0,0,0,.3);
}
.ft-cookie.show { transform: translateY(0); }
.ft-cookie-text {
  flex: 1; min-width: 200px;
  font-size: .82rem; color: var(--ft-text); line-height: 1.5;
}
.ft-cookie-text a { color: var(--ft-primary); }
.ft-cookie-btns { display: flex; gap: 8px; flex-shrink: 0; }
.ft-cookie-accept, .ft-cookie-decline {
  border: none; border-radius: 50px;
  padding: 9px 22px; font-family: var(--ft-font);
  font-size: .82rem; font-weight: 700; cursor: pointer;
  transition: filter var(--ft-transition);
}
.ft-cookie-accept  { background: var(--ft-primary); color: #fff; }
.ft-cookie-decline { background: rgba(255,255,255,.08); color: var(--ft-text); }
.ft-cookie-accept:hover, .ft-cookie-decline:hover { filter: brightness(1.1); }

/* ══════════════════════
   RESPONSIVE — Tablet
══════════════════════ */
@media (max-width: 1100px) {
  .ft-main-inner {
    grid-template-columns: 1fr 1fr 1fr;
    gap: 36px;
  }
  .ft-brand { grid-column: 1 / -1; }
  .ft-brand-desc { max-width: 100%; }
  .ft-trust-inner { grid-template-columns: repeat(2, 1fr); }
}

/* ══════════════════════
   RESPONSIVE — Mobile
══════════════════════ */
@media (max-width: 768px) {
  .ft-newsletter { padding: 28px 16px; }
  .ft-nl-title   { font-size: 1.15rem; }
  .ft-nl-inner   { gap: 20px; }

  .ft-trust-inner { grid-template-columns: repeat(2, 1fr); }
  .ft-trust-item  { padding: 14px 16px; border-right: none; border-bottom: 1px solid var(--ft-border); }
  .ft-trust-item:nth-child(odd)  { border-right: 1px solid var(--ft-border); }
  .ft-trust-item:nth-last-child(-n+2) { border-bottom: none; }

  .mcp-footer { padding: 40px 16px 0; }
  .ft-main-inner {
    grid-template-columns: 1fr 1fr;
    gap: 28px;
  }
  .ft-brand { grid-column: 1 / -1; }

  /* Accordion columns on mobile */
  .ft-col { border-bottom: 1px solid var(--ft-border); }
  .ft-col-title {
    width: 100%; cursor: pointer;
    display: flex; justify-content: space-between;
    align-items: center; border-bottom: none;
    margin-bottom: 0; padding-bottom: 14px;
  }
  .ft-col-title::after {
    content: '\f078'; font-family: 'Font Awesome 6 Free';
    font-weight: 900; font-size: .65rem; color: var(--ft-text2);
    transition: transform var(--ft-transition);
  }
  .ft-col.open .ft-col-title::after { transform: rotate(180deg); }
  .ft-col-body { display: none; padding-bottom: 14px; }
  .ft-col.open .ft-col-body { display: block; }

  .ft-payments { flex-direction: column; align-items: flex-start; }
  .ft-bottom-inner { flex-direction: column; align-items: flex-start; gap: 8px; }
  .ft-back-top { bottom: 80px; right: 14px; width: 42px; height: 42px; }

  .ft-social-btn { width: 40px; height: 40px; }
}

@media (max-width: 480px) {
  .ft-main-inner { grid-template-columns: 1fr; }
  .ft-nl-form { flex-direction: column; border-radius: 12px; padding: 10px; gap: 8px; }
  .ft-nl-input { padding: 10px 12px; }
  .ft-nl-btn { border-radius: var(--ft-radius-sm); width: 100%; padding: 12px; }
  .ft-trust-inner { grid-template-columns: 1fr 1fr; }
  .ft-trust-item { padding: 12px; }
  .ft-trust-icon { width: 36px; height: 36px; }
}
</style>

<!-- Back to Top -->
<button class="ft-back-top" id="ftBackTop" aria-label="Back to top" onclick="mcpScrollTop()">
  <i class="fas fa-chevron-up"></i>
</button>

<!-- Newsletter Strip -->
<div class="ft-newsletter">
  <div class="ft-nl-inner">
    <div class="ft-nl-text">
      <div class="ft-nl-title">
        💊 Get <span>Health Tips</span> & Exclusive Offers
      </div>
      <div class="ft-nl-sub">
        <?php _e('Join 50,000+ customers. No spam, only deals.', 'medicare-plus'); ?>
      </div>
      <div class="ft-nl-trust" style="margin-top:8px;">
        <span><i class="fas fa-shield-halved"></i> <?php _e('Privacy protected', 'medicare-plus'); ?></span>
        <span><i class="fas fa-bell-slash"></i> <?php _e('Unsubscribe anytime', 'medicare-plus'); ?></span>
      </div>
    </div>
    <div>
      <div class="ft-nl-form" id="ftNlForm">
        <input type="email" class="ft-nl-input" id="ftNlEmail"
               placeholder="<?php esc_attr_e('Your email address…', 'medicare-plus'); ?>"
               autocomplete="email">
        <button class="ft-nl-btn" onclick="ftSubscribe()">
          <i class="fas fa-paper-plane" style="margin-right:6px;"></i>
          <?php _e('Subscribe', 'medicare-plus'); ?>
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Trust Badges Bar -->
<div class="ft-trust-bar">
  <div class="ft-trust-inner">
    <div class="ft-trust-item">
      <div class="ft-trust-icon" style="background:rgba(30,136,229,.15);">
        <i class="fas fa-truck-fast" style="color:#1E88E5;"></i>
      </div>
      <div class="ft-trust-content">
        <div class="ft-trust-title"><?php _e('Fast Delivery', 'medicare-plus'); ?></div>
        <div class="ft-trust-sub"><?php _e('Same-day in select cities', 'medicare-plus'); ?></div>
      </div>
    </div>
    <div class="ft-trust-item">
      <div class="ft-trust-icon" style="background:rgba(67,160,71,.15);">
        <i class="fas fa-certificate" style="color:#43A047;"></i>
      </div>
      <div class="ft-trust-content">
        <div class="ft-trust-title"><?php _e('100% Genuine', 'medicare-plus'); ?></div>
        <div class="ft-trust-sub"><?php _e('Certified & licensed products', 'medicare-plus'); ?></div>
      </div>
    </div>
    <div class="ft-trust-item">
      <div class="ft-trust-icon" style="background:rgba(0,172,193,.15);">
        <i class="fas fa-rotate-left" style="color:#00ACC1;"></i>
      </div>
      <div class="ft-trust-content">
        <div class="ft-trust-title"><?php _e('Easy Returns', 'medicare-plus'); ?></div>
        <div class="ft-trust-sub"><?php _e('7-day hassle-free returns', 'medicare-plus'); ?></div>
      </div>
    </div>
    <div class="ft-trust-item">
      <div class="ft-trust-icon" style="background:rgba(239,83,80,.15);">
        <i class="fas fa-headset" style="color:#EF5350;"></i>
      </div>
      <div class="ft-trust-content">
        <div class="ft-trust-title"><?php _e('24×7 Support', 'medicare-plus'); ?></div>
        <div class="ft-trust-sub"><?php _e('Expert pharmacist helpline', 'medicare-plus'); ?></div>
      </div>
    </div>
  </div>
</div>

<!-- ── MAIN FOOTER ── -->
<footer class="mcp-footer" role="contentinfo">
  <div class="ft-main-inner">

    <!-- Brand Column -->
    <div class="ft-brand">
      <a class="ft-logo" href="<?php echo esc_url(home_url('/')); ?>">
        <div class="ft-logo-icon"><i class="fas fa-plus"></i></div>
        <div class="ft-logo-text">
          <?php
          $logo_text = get_option('mcp_logo_text', get_bloginfo('name'));
          $parts = explode('+', $logo_text, 2);
          echo esc_html($parts[0]);
          if (isset($parts[1])) echo '<span class="ft-logo-plus">+' . esc_html($parts[1]) . '</span>';
          ?>
        </div>
      </a>
      <p class="ft-brand-desc">
        <?php echo esc_html(get_option('mcp_footer_about', 'India\'s trusted online pharmacy delivering genuine medicines, wellness products & healthcare essentials to your doorstep — fast, safe & affordable.')); ?>
      </p>
      <?php $ft_license = get_option('mcp_footer_license', ''); if (!empty($ft_license)) : ?>
      <div class="ft-license-badge">
        <i class="fas fa-certificate"></i>
        <?php echo esc_html($ft_license); ?>
      </div>
      <?php endif; ?>

      <div class="ft-social">
        <?php $fb = get_option('mcp_social_facebook','#'); if($fb && $fb!='#'): ?>
        <a class="ft-social-btn fb" href="<?php echo esc_url($fb); ?>" target="_blank" rel="noopener" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <?php endif; ?>
        <?php $ig = get_option('mcp_social_instagram','#'); if($ig && $ig!='#'): ?>
        <a class="ft-social-btn ig" href="<?php echo esc_url($ig); ?>" target="_blank" rel="noopener" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
        <?php endif; ?>
        <?php $tw = get_option('mcp_social_twitter','#'); if($tw && $tw!='#'): ?>
        <a class="ft-social-btn tw" href="<?php echo esc_url($tw); ?>" target="_blank" rel="noopener" aria-label="Twitter"><i class="fab fa-x-twitter"></i></a>
        <?php endif; ?>
        <?php $wa = get_option('mcp_whatsapp_number'); if($wa): ?>
        <a class="ft-social-btn wa" href="https://wa.me/<?php echo esc_attr($wa); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
        <?php endif; ?>
        <?php $yt = get_option('mcp_social_youtube','#'); if($yt && $yt!='#'): ?>
        <a class="ft-social-btn yt" href="<?php echo esc_url($yt); ?>" target="_blank" rel="noopener" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
        <?php endif; ?>
      </div>

      <?php
        $playstore = get_option('mcp_app_playstore', '');
        $appstore  = get_option('mcp_app_appstore', '');
        $has_playstore = !empty($playstore) && $playstore !== '#';
        $has_appstore  = !empty($appstore)  && $appstore  !== '#';
        if ($has_playstore || $has_appstore) :
      ?>
      <div class="ft-app-title"><?php _e('Download App', 'medicare-plus'); ?></div>
      <div class="ft-app-btns">
        <?php if ($has_playstore) : ?>
        <a class="ft-app-btn" href="<?php echo esc_url($playstore); ?>" target="_blank" rel="noopener">
          <i class="fab fa-google-play"></i>
          <div class="ft-app-btn-text">
            <span class="ft-app-btn-sub"><?php _e('Get it on', 'medicare-plus'); ?></span>
            <span class="ft-app-btn-main">Google Play</span>
          </div>
        </a>
        <?php endif; ?>
        <?php if ($has_appstore) : ?>
        <a class="ft-app-btn" href="<?php echo esc_url($appstore); ?>" target="_blank" rel="noopener">
          <i class="fab fa-apple"></i>
          <div class="ft-app-btn-text">
            <span class="ft-app-btn-sub"><?php _e('Download on', 'medicare-plus'); ?></span>
            <span class="ft-app-btn-main">App Store</span>
          </div>
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Quick Links -->
    <div class="ft-col" id="ftCol1">
      <div class="ft-col-title" onclick="ftToggleCol('ftCol1')">
        <?php _e('Quick Links', 'medicare-plus'); ?>
      </div>
      <div class="ft-col-body">
        <ul class="ft-links">
          <li><a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"><i class="fas fa-chevron-right"></i><?php _e('Shop All', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/offers/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Today\'s Deals', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/upload-prescription/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Upload Prescription', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/health-blog/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Health Blog', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/lab-tests/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Lab Tests', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/consult-doctor/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Consult Doctor', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/track-order/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Track Order', 'medicare-plus'); ?></a></li>
        </ul>
      </div>
    </div>

    <!-- Categories -->
    <div class="ft-col" id="ftCol2">
      <div class="ft-col-title" onclick="ftToggleCol('ftCol2')">
        <?php _e('Categories', 'medicare-plus'); ?>
      </div>
      <div class="ft-col-body">
        <ul class="ft-links">
          <?php
          $ft_cats = get_terms(['taxonomy'=>'product_cat','orderby'=>'count','order'=>'DESC','hide_empty'=>true,'number'=>8,'parent'=>0]);
          $emojis  = ['medicines'=>'💊','healthcare'=>'❤️','personal-care'=>'🧴','baby-care'=>'👶','ayurveda'=>'🌿','devices'=>'🩺','vitamins'=>'🍊','supplements'=>'💪','skincare'=>'✨','eye-care'=>'👁️'];
          if (!is_wp_error($ft_cats)) :
            foreach ($ft_cats as $fc) :
              $em = $emojis[strtolower($fc->slug)] ?? '🏥';
          ?>
          <li>
            <a href="<?php echo esc_url(get_term_link($fc)); ?>">
              <i class="fas fa-chevron-right"></i>
              <?php echo $em . ' ' . esc_html($fc->name); ?>
            </a>
          </li>
          <?php endforeach; endif; ?>
        </ul>
      </div>
    </div>

    <!-- Help & Policy -->
    <div class="ft-col" id="ftCol3">
      <div class="ft-col-title" onclick="ftToggleCol('ftCol3')">
        <?php _e('Help & Policies', 'medicare-plus'); ?>
      </div>
      <div class="ft-col-body">
        <ul class="ft-links">
          <li><a href="<?php echo esc_url(home_url('/about-us/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('About Us', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/contact-us/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Contact Us', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><i class="fas fa-chevron-right"></i><?php _e('Privacy Policy', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/terms/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Terms & Conditions', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/refund-policy/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Refund Policy', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/shipping-policy/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('Shipping Policy', 'medicare-plus'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/faq/')); ?>"><i class="fas fa-chevron-right"></i><?php _e('FAQ', 'medicare-plus'); ?></a></li>
        </ul>
      </div>
    </div>

    <!-- Contact Column -->
    <div class="ft-col" id="ftCol4">
      <div class="ft-col-title" onclick="ftToggleCol('ftCol4')">
        <?php _e('Contact Us', 'medicare-plus'); ?>
      </div>
      <div class="ft-col-body">
        <div class="ft-contact-list">
          <div class="ft-contact-item">
            <div class="ft-contact-icon" style="background:rgba(30,136,229,.15);">
              <i class="fas fa-phone" style="color:#1E88E5;"></i>
            </div>
            <div class="ft-contact-text">
              <div class="ft-contact-label"><?php _e('Helpline', 'medicare-plus'); ?></div>
              <div class="ft-contact-val">
                <a href="tel:<?php echo esc_attr(get_option('mcp_phone_number','1800-123-4567')); ?>">
                  <?php echo esc_html(get_option('mcp_phone_number','1800-123-4567')); ?>
                </a>
              </div>
            </div>
          </div>
          <div class="ft-contact-item">
            <div class="ft-contact-icon" style="background:rgba(37,211,102,.15);">
              <i class="fab fa-whatsapp" style="color:#25D366;"></i>
            </div>
            <div class="ft-contact-text">
              <div class="ft-contact-label">WhatsApp</div>
              <div class="ft-contact-val">
                <?php $wa_num = get_option('mcp_whatsapp_number','919876543210'); ?>
                <a href="https://wa.me/<?php echo esc_attr($wa_num); ?>" target="_blank">
                  +<?php echo esc_html(substr($wa_num,0,2).' '.substr($wa_num,2,5).' '.substr($wa_num,7)); ?>
                </a>
              </div>
            </div>
          </div>
          <div class="ft-contact-item">
            <div class="ft-contact-icon" style="background:rgba(239,83,80,.15);">
              <i class="fas fa-envelope" style="color:#EF5350;"></i>
            </div>
            <div class="ft-contact-text">
              <div class="ft-contact-label"><?php _e('Email', 'medicare-plus'); ?></div>
              <div class="ft-contact-val">
                <a href="mailto:<?php echo esc_attr(get_option('mcp_email','support@medicareplus.in')); ?>">
                  <?php echo esc_html(get_option('mcp_email','support@medicareplus.in')); ?>
                </a>
              </div>
            </div>
          </div>
          <div class="ft-contact-item">
            <div class="ft-contact-icon" style="background:rgba(255,213,79,.1);">
              <i class="fas fa-location-dot" style="color:#FFD54F;"></i>
            </div>
            <div class="ft-contact-text">
              <div class="ft-contact-label"><?php _e('Address', 'medicare-plus'); ?></div>
              <div class="ft-contact-val">
                <?php echo nl2br(esc_html(get_option('mcp_address','123 Health Street,\nNew Delhi - 110001'))); ?>
              </div>
            </div>
          </div>
        </div>
        <div class="ft-timing">
          <i class="fas fa-clock"></i>
          <div class="ft-timing-text">
            <div class="ft-timing-main"><?php _e('Mon – Sat: 9AM – 9PM', 'medicare-plus'); ?></div>
            <div class="ft-timing-sub"><?php _e('Sunday: 10AM – 6PM', 'medicare-plus'); ?></div>
          </div>
        </div>
      </div>
    </div>

  </div><!-- /ft-main-inner -->

  <hr class="ft-divider">

  <!-- Payment Methods -->
  <div class="ft-payments">
    <span class="ft-pay-label"><i class="fas fa-lock" style="margin-right:5px;color:#43A047;"></i><?php _e('Secure Payments', 'medicare-plus'); ?></span>
    <div class="ft-pay-icons">
      <span class="ft-pay-badge visa">VISA</span>
      <span class="ft-pay-badge mc">MasterCard</span>
      <span class="ft-pay-badge upi">UPI</span>
      <span class="ft-pay-badge paytm">Paytm</span>
      <span class="ft-pay-badge">PhonePe</span>
      <span class="ft-pay-badge">GPay</span>
      <span class="ft-pay-badge">Net Banking</span>
      <span class="ft-pay-badge cod">COD</span>
    </div>
    <div class="ft-ssl-badge">
      <i class="fas fa-shield-halved"></i>
      <?php _e('SSL Secured', 'medicare-plus'); ?>
    </div>
  </div>

  <!-- Bottom Bar -->
  <div class="ft-bottom">
    <div class="ft-bottom-inner">
      <div class="ft-copy">
        © <?php echo date('Y'); ?> <span><?php echo esc_html(get_option('mcp_footer_copy_name', get_bloginfo('name'))); ?></span>.
        <?php _e('All rights reserved.', 'medicare-plus'); ?>
        <?php if(get_option('mcp_footer_license_short')) : ?>
          &nbsp;·&nbsp; <?php echo esc_html(get_option('mcp_footer_license_short','Drug Lic: DL/DRG/000123')); ?>
        <?php endif; ?>
      </div>
      <div class="ft-bottom-links">
        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php _e('Privacy', 'medicare-plus'); ?></a>
        <span>|</span>
        <a href="<?php echo esc_url(home_url('/terms/')); ?>"><?php _e('Terms', 'medicare-plus'); ?></a>
        <span>|</span>
        <a href="<?php echo esc_url(home_url('/sitemap.xml')); ?>"><?php _e('Sitemap', 'medicare-plus'); ?></a>
        <span>|</span>
        <a href="<?php echo esc_url(home_url('/contact-us/')); ?>"><?php _e('Contact', 'medicare-plus'); ?></a>
      </div>
    </div>
  </div>

</footer>

<!-- Cookie Banner -->
<div class="ft-cookie" id="ftCookieBanner">
  <div class="ft-cookie-text">
    🍪 <?php printf(
      wp_kses(__('We use cookies to enhance your experience. By continuing, you agree to our <a href="%s">Cookie Policy</a>.', 'medicare-plus'), ['a'=>['href'=>[]]]),
      esc_url(get_privacy_policy_url())
    ); ?>
  </div>
  <div class="ft-cookie-btns">
    <button class="ft-cookie-accept" onclick="ftAcceptCookie()">
      <i class="fas fa-check" style="margin-right:5px;"></i><?php _e('Accept', 'medicare-plus'); ?>
    </button>
    <button class="ft-cookie-decline" onclick="ftDeclineCookie()">
      <?php _e('Decline', 'medicare-plus'); ?>
    </button>
  </div>
</div>

<?php wp_footer(); ?>

<!-- ═══════════════════════════════════
     FOOTER JAVASCRIPT
═══════════════════════════════════ -->
<script>
(function () {
  'use strict';

  /* ── Back to Top ── */
  var backTop = document.getElementById('ftBackTop');
  window.addEventListener('scroll', function () {
    if (backTop) backTop.classList.toggle('show', window.scrollY > 400);
  }, { passive: true });
  window.mcpScrollTop = function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  /* ── Mobile Column Accordion ── */
  window.ftToggleCol = function (id) {
    if (window.innerWidth > 768) return; // desktop = always open
    var col = document.getElementById(id);
    if (!col) return;
    col.classList.toggle('open');
  };

  // On desktop keep all open; ensure correct state on resize
  function ftHandleResize() {
    var cols = document.querySelectorAll('.ft-col');
    if (window.innerWidth > 768) {
      cols.forEach(function (c) { c.classList.remove('open'); });
      document.querySelectorAll('.ft-col-body').forEach(function (b) {
        b.style.display = '';
      });
    }
  }
  window.addEventListener('resize', ftHandleResize, { passive: true });

  /* ── Newsletter Subscribe ── */
  window.ftSubscribe = function () {
    var emailEl = document.getElementById('ftNlEmail');
    var email   = emailEl ? emailEl.value.trim() : '';
    var re      = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email || !re.test(email)) {
      emailEl && emailEl.focus();
      if (typeof mcpShowToast === 'function') {
        mcpShowToast('<?php echo esc_js(__("Please enter a valid email address.", "medicare-plus")); ?>');
      }
      return;
    }

    /* WP AJAX call — hook 'mcp_newsletter_subscribe' in functions.php */
    var fd = new FormData();
    fd.append('action', 'mcp_newsletter_subscribe');
    fd.append('email',  email);
    fd.append('nonce',  typeof mcpAjax !== 'undefined' ? mcpAjax.nonce : '');

    fetch(typeof mcpAjax !== 'undefined'
      ? mcpAjax.url
      : '<?php echo esc_url(admin_url("admin-ajax.php")); ?>',
      { method: 'POST', body: fd }
    ).then(function (r) { return r.json(); })
     .then(function (data) {
       var msg = (data && data.success)
         ? '<?php echo esc_js(__("Thank you! You are now subscribed. 🎉", "medicare-plus")); ?>'
         : '<?php echo esc_js(__("Something went wrong. Please try again.", "medicare-plus")); ?>';
       if (typeof mcpShowToast === 'function') mcpShowToast(msg, 4000);
       if (data && data.success && emailEl) emailEl.value = '';
     })
     .catch(function () {
       // Fallback: mailto
       window.location.href = 'mailto:<?php echo esc_js(get_option("mcp_email","support@medicareplus.in")); ?>?subject=Subscribe&body=' + encodeURIComponent(email);
     });
  };

  document.getElementById('ftNlEmail') &&
  document.getElementById('ftNlEmail').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') ftSubscribe();
  });

  /* ── Cookie Banner ── */
  var cookieBanner = document.getElementById('ftCookieBanner');

  function ftCheckCookie() {
    try {
      if (!localStorage.getItem('mcp_cookie_consent')) {
        setTimeout(function () {
          cookieBanner && cookieBanner.classList.add('show');
        }, 2000);
      }
    } catch (e) {}
  }

  window.ftAcceptCookie = function () {
    try { localStorage.setItem('mcp_cookie_consent', '1'); } catch (e) {}
    cookieBanner && cookieBanner.classList.remove('show');
    if (typeof mcpShowToast === 'function') {
      mcpShowToast('<?php echo esc_js(__("Preferences saved. Thank you! ✓", "medicare-plus")); ?>');
    }
  };

  window.ftDeclineCookie = function () {
    try { localStorage.setItem('mcp_cookie_consent', '0'); } catch (e) {}
    cookieBanner && cookieBanner.classList.remove('show');
  };

  ftCheckCookie();

  /* ── Lazy-load footer images ── */
  if ('IntersectionObserver' in window) {
    var lazyImgs = document.querySelectorAll('.mcp-footer img[data-src]');
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.src = en.target.dataset.src;
          observer.unobserve(en.target);
        }
      });
    }, { rootMargin: '120px' });
    lazyImgs.forEach(function (img) { observer.observe(img); });
  }

})();
</script>

</body>
</html>