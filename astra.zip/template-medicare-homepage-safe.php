<?php
/**
 * Template Name: MediCare+ App Homepage Master
 * Description: Fully functional unified app-like layout. CRASH-PROOF VERSION.
 *
 * WOOCOMMERCE AJAX ORDER HANDLER
 * ---------------------------------------------------------------
 * The order-creation logic has been moved to functions.php as a
 * proper wp_ajax action. It CANNOT run inside a template file
 * because wp_send_json / wc_create_order require WordPress to be
 * fully bootstrapped first.
 *
 * Add the following to your child-theme functions.php:
 *
 *   add_action('wp_ajax_mc_place_order',       'mc_ajax_place_order');
 *   add_action('wp_ajax_nopriv_mc_place_order','mc_ajax_place_order');
 *   function mc_ajax_place_order() {
 *       if (!check_ajax_referer('mc_order_nonce','security',false)) {
 *           wp_send_json_error(['message'=>'Security check failed.']); return;
 *       }
 *       if (!class_exists('WooCommerce')) {
 *           wp_send_json_error(['message'=>'WooCommerce not active.']); return;
 *       }
 *       $cart_data = json_decode(stripslashes($_POST['cart_data']),true);
 *       $name      = sanitize_text_field($_POST['name']);
 *       $phone     = sanitize_text_field($_POST['phone']);
 *       $address   = sanitize_text_field($_POST['address']);
 *       if (empty($cart_data)||!$name||!$phone||!$address) {
 *           wp_send_json_error(['message'=>'Missing required fields.']); return;
 *       }
 *       try {
 *           $order = wc_create_order();
 *           foreach ($cart_data as $item) {
 *               $product = wc_get_product(intval($item['id']));
 *               if ($product) $order->add_product($product, intval($item['qty']));
 *           }
 *           $addr = ['first_name'=>$name,'phone'=>$phone,'address_1'=>$address,
 *                    'city'=>get_option('woocommerce_store_city','Peshawar'),'country'=>'PK'];
 *           $order->set_address($addr,'billing');
 *           $order->set_address($addr,'shipping');
 *           $order->set_payment_method('cod');
 *           $order->set_payment_method_title('Cash on Delivery');
 *           $order->calculate_totals();
 *           $order->update_status('processing','Order via MediCare+ Homepage.');
 *           wp_send_json_success(['order_id'=>$order->get_id()]);
 *       } catch (Exception $e) {
 *           wp_send_json_error(['message'=>$e->getMessage()]);
 *       }
 *   }
 */

get_header(); 

// Ensure WooCommerce is active before proceeding
if ( ! class_exists( 'WooCommerce' ) ) {
    echo '<div style="padding:50px; text-align:center; color:red;"><h2>WooCommerce is missing or deactivated! Please activate WooCommerce plugin.</h2></div>';
    get_footer();
    exit;
}

/* ============================================================
   BACKEND CORE ENGINE: PRODUCT ARCHITECTURE & MAPPER
   ============================================================ */
$mc_js_products = [
    'bestSelling' => [],
    'featured'    => [],
    'herbal'      => [],
    'baby'        => [],
    'devices'     => [],
    'newArrivals' => []
];

if (!function_exists('mc_map_wc_product_to_js_state')) {
    function mc_map_wc_product_to_js_state($product) {
        $price = (float)$product->get_price();
        $reg_price = (float)$product->get_regular_price();
        $sale_pct = ($reg_price && $price < $reg_price) ? round((($reg_price - $price) / $reg_price) * 100) . '% OFF' : '';
        $img_id = $product->get_image_id();
        $img_url = $img_id ? wp_get_attachment_image_url($img_id, 'woocommerce_thumbnail') : '';
        
        return [
            'id'      => $product->get_id(),
            'name'    => esc_js($product->get_name()),
            'sub'     => esc_js(wp_strip_all_tags($product->get_short_description()) ?: 'Premium Quality'),
            'price'   => $price,
            'old'     => $reg_price ?: $price,
            'disc'    => $sale_pct ?: 'SALE',
            'img'     => esc_url($img_url),
            'rating'  => (float)$product->get_average_rating(),
            'reviews' => (int)$product->get_rating_count(),
            'desc'    => esc_js(wp_strip_all_tags($product->get_description()) ?: 'Tested and verified item.')
        ];
    }
}

if (!function_exists('mc_fetch_products_safely')) {
    function mc_fetch_products_safely($query_args) {
        $query = new WC_Product_Query($query_args);
        $products = $query->get_products();
        if (empty($products)) {
            unset($query_args['category']);
            unset($query_args['visibility']);
            $query_args['orderby'] = 'date';
            $query_args['order'] = 'DESC';
            $query_args['limit'] = 6;
            $fallback_query = new WC_Product_Query($query_args);
            $products = $fallback_query->get_products();
        }
        return $products;
    }
}

$bs_list = mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'orderby' => 'popularity', 'order' => 'DESC']);
foreach ($bs_list as $p) { $mc_js_products['bestSelling'][] = mc_map_wc_product_to_js_state($p); }

$feat_ids  = wc_get_featured_product_ids();
$feat_list = !empty($feat_ids)
    ? mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'include' => array_slice($feat_ids, 0, 6)])
    : mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'orderby' => 'rating', 'order' => 'DESC']);
foreach ($feat_list as $p) { $mc_js_products['featured'][] = mc_map_wc_product_to_js_state($p); }

$herb_list = mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'category' => ['ayurveda']]);
foreach ($herb_list as $p) { $mc_js_products['herbal'][] = mc_map_wc_product_to_js_state($p); }

$baby_list = mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'category' => ['baby-care']]);
foreach ($baby_list as $p) { $mc_js_products['baby'][] = mc_map_wc_product_to_js_state($p); }

$dev_list = mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'category' => ['devices']]);
foreach ($dev_list as $p) { $mc_js_products['devices'][] = mc_map_wc_product_to_js_state($p); }

$new_list = mc_fetch_products_safely(['limit' => 6, 'status' => 'publish', 'orderby' => 'date', 'order' => 'DESC']);
foreach ($new_list as $p) { $mc_js_products['newArrivals'][] = mc_map_wc_product_to_js_state($p); }
?>

<!-- ============================================================
     CSS STYLES
     ============================================================ -->
<style>
.page-template-template-medicare-homepage-php #primary,
.page-template-template-medicare-homepage-master #primary { width: 100% !important; max-width: 100% !important; padding: 0 !important; margin: 0 !important; float: none !important; box-sizing: border-box; }
.page-template-template-medicare-homepage-php #secondary, .page-template-template-medicare-homepage-php .sidebar,
.page-template-template-medicare-homepage-master #secondary, .page-template-template-medicare-homepage-master .sidebar { display: none !important; }
.page-template-template-medicare-homepage-master .site-content .ast-container { max-width: 100% !important; padding: 0 !important; margin: 0 !important; }

:root {
  --blue: #1565C0;
  --blue-light: #1976D2;
  --blue-soft: #E3F0FF;
  --green: #2E7D32;
  --green-light: #43A047;
  --green-soft: #E8F5E9;
  --white: #ffffff;
  --bg: #F4F7FB;
  --gray: #6B7280;
  --gray-light: #E5E9F0;
  --dark: #0F172A;
  --red: #E53935;
  --orange: #FB8C00;
  --yellow: #FDD835;
  --shadow-sm: 0 2px 8px rgba(21,101,192,0.08);
  --shadow-md: 0 4px 20px rgba(21,101,192,0.13);
  --shadow-lg: 0 8px 40px rgba(21,101,192,0.18);
  --radius: 16px;
  --radius-sm: 10px;
  --radius-full: 100px;
  --transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
  --glass: rgba(255,255,255,0.85);
  --glass-border: rgba(255,255,255,0.6);
}

.mc-master-app-wrapper { width: 100%; max-width: 1200px; margin: 0 auto; background: var(--bg); font-family: 'Poppins', sans-serif; box-sizing: border-box; padding: 10px 15px 90px 15px; position: relative; }
.delivery-bar { background:var(--green-soft); display:flex; align-items:center; justify-content:space-between; padding:12px 16px; font-size:0.75rem; color:var(--green); border-radius: 8px; margin-bottom: 15px; }
.delivery-bar .loc { display:flex; align-items:center; gap:5px; font-weight:600; }
.delivery-bar .free { display:flex; align-items:center; gap:5px; font-weight:700; color:var(--green-light); }

.hero { background:linear-gradient(135deg,#EBF4FF 0%,#E8F5E9 100%); border-radius:var(--radius); overflow:hidden; position:relative; padding:35px 25px; box-shadow:var(--shadow-sm); border:1px solid var(--glass-border); margin-bottom: 20px; }
.hero-content { position:relative; z-index:2; max-width: 650px; }
.hero-badge { display:inline-flex; align-items:center; gap:5px; background:rgba(21,101,192,0.1); color:var(--blue); font-size:0.72rem; font-weight:600; padding:4px 12px; border-radius:var(--radius-full); margin-bottom:12px; border:1px solid rgba(21,101,192,0.2); }
.hero h1 { font-size:2.2rem !important; font-weight:800 !important; line-height:1.2 !important; color:var(--dark) !important; margin-bottom:12px !important; }
.hero h1 span { color:var(--blue); }
.hero p { font-size:0.9rem; color:var(--gray); margin-bottom:20px; }
.btn-primary { background:linear-gradient(135deg,var(--blue),var(--blue-light)); color:#fff !important; padding:12px 24px; border-radius:var(--radius-full); font-size:0.85rem; font-weight:600; box-shadow:0 4px 14px rgba(21,101,192,0.3); display:inline-flex; align-items:center; gap:6px; text-decoration:none; border:none; cursor:pointer; }
.btn-outline { background:rgba(255,255,255,0.8); color:var(--blue) !important; border:1.5px solid var(--blue); padding:11px 22px; border-radius:var(--radius-full); font-size:0.85rem; font-weight:600; display:inline-flex; align-items:center; gap:6px; text-decoration:none; cursor:pointer; }

.hero-search { display:flex; align-items:center; background:#fff; border-radius:var(--radius-full); padding:6px 6px 6px 16px; box-shadow:var(--shadow-md); margin-top:24px; border:1.5px solid var(--gray-light); max-width: 500px; }
.hero-search input { flex:1; font-size:0.88rem; color:var(--dark); background:transparent; border:none !important; outline:none !important; }
.hero-search button { background:linear-gradient(135deg,var(--blue),var(--blue-light)); color:#fff; padding:10px 22px; border-radius:var(--radius-full); font-size:0.88rem; font-weight:600; border:none; cursor:pointer; }

.section-pad { width: 100%; margin-bottom: 25px; box-sizing: border-box; }
.section-title-row { display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; }
.section-title { font-size:1.2rem; font-weight:700; color:var(--dark); margin: 0; }
.view-all { font-size:0.85rem; color:var(--blue); font-weight:600; text-decoration:none; cursor: pointer; }

.cat-scroll, .prod-slider { display:flex; gap:14px; overflow-x:auto; padding-bottom:10px; width: 100%; box-sizing: border-box; }
.cat-scroll::-webkit-scrollbar, .prod-slider::-webkit-scrollbar { height: 4px; }
.cat-scroll::-webkit-scrollbar-thumb, .prod-slider::-webkit-scrollbar-thumb { background: var(--gray-light); border-radius: 10px; }

.cat-pill { display:flex; flex-direction:column; align-items:center; gap:8px; flex-shrink:0; cursor:pointer; width: 85px; }
.cat-icon { width:64px; height:64px; border-radius:18px; display:flex; align-items:center; justify-content:center; font-size:1.8rem; background:#fff; box-shadow:var(--shadow-sm); border:1.5px solid var(--gray-light); transition:var(--transition); }
.cat-pill:hover .cat-icon { border-color:var(--blue); transform: translateY(-2px); background: var(--blue-soft); }
.cat-label { font-size:0.75rem; font-weight:600; color:var(--gray); text-align:center; }

.prod-card { flex-shrink:0; width:165px; background:#fff; border-radius:var(--radius); padding:14px; box-shadow:var(--shadow-sm); border:1.5px solid var(--gray-light); position:relative; cursor:pointer; transition:var(--transition); display: flex; flex-direction: column; justify-content: space-between; box-sizing: border-box; }
.prod-card:hover { box-shadow:var(--shadow-md); transform:translateY(-3px); border-color:var(--blue-light); }
.prod-badge { position:absolute; top:10px; left:10px; background:linear-gradient(135deg,var(--red),#EF5350); color:#fff; font-size:0.6rem; font-weight:700; padding:3px 8px; border-radius:var(--radius-full); z-index: 3; }
.prod-img { width:100%; height:110px; display:flex; align-items:center; justify-content:center; background:var(--bg); border-radius:var(--radius-sm); margin:6px 0; overflow:hidden; }
.prod-img img { max-height:95px; object-fit:contain; }
.prod-img .prod-emoji { font-size: 2.8rem; }
.prod-name { font-size:0.85rem; font-weight:600; color:var(--dark); margin-bottom:3px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.prod-sub { font-size:0.72rem; color:var(--gray); margin-bottom:8px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.prod-stars { display:flex; align-items:center; gap:2px; margin-bottom:6px; font-size: 0.65rem; color: var(--yellow); }
.prod-stars span { color: var(--gray); margin-left: 2px; }
.prod-price { display:flex; align-items:baseline; gap:6px; margin-bottom:10px; }
.price { font-size:0.95rem; font-weight:700; color:var(--blue); }
.old { font-size:0.72rem; color:var(--gray); text-decoration:line-through; }
.btn-add { width:100%; background:linear-gradient(135deg,var(--blue),var(--blue-light)); color:#fff !important; padding:9px 0; border-radius:var(--radius-sm); font-size:0.78rem; font-weight:600; text-align:center; border: none; cursor: pointer; box-shadow: 0 2px 8px rgba(21,101,192,0.2); }
.prod-card .quick-view { position:absolute; bottom:48px; left:14px; right:14px; background:rgba(21,101,192,0.92); color:#fff; text-align:center; font-size:0.7rem; font-weight:600; padding:6px 0; border-radius:6px; opacity:0; transition:var(--transition); }
.prod-card:hover .quick-view { opacity:1; }



.mc-offer-slider { display:flex; gap:16px; overflow-x:auto; padding-bottom: 5px; }
.mc-offer-card { flex-shrink:0; width: 100%; max-width: 360px; border-radius:var(--radius); padding:22px; display:flex; align-items:center; justify-content:space-between; position:relative; overflow:hidden; min-height:120px; box-sizing: border-box; }
.mc-offer-card-1 { background:linear-gradient(135deg,#1565C0,#1E88E5); }
.mc-offer-card-2 { background:linear-gradient(135deg,#2E7D32,#43A047); }
.mc-offer-content { position:relative; z-index:2; color: #fff; }
.mc-percent { font-size:1.8rem; font-weight:900; }
.mc-text { font-size:0.88rem; margin:4px 0; }
.mc-offer-btn { background:#fff; color:var(--blue); padding:7px 16px; border-radius:var(--radius-full); font-size:0.75rem; font-weight:700; margin-top:12px; display:inline-block; text-decoration:none; border: none; cursor:pointer; }

.mc-trust-strip { display:flex; margin:25px 0; background:#fff; border-radius:var(--radius); box-shadow:var(--shadow-sm); border:1.5px solid var(--gray-light); overflow:hidden; }
.trust-item { flex:1; display:flex; flex-direction:column; align-items:center; padding:14px 8px; gap:5px; border-right:1px solid var(--gray-light); text-align:center; }
.trust-item:last-child { border-right:none; }
.trust-item i { font-size:1.2rem; color:var(--blue); }
.t-title { font-size:0.72rem; font-weight:700; color:var(--dark); }

.action-banners { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin:20px 0; }
.action-card { background:#fff; border-radius:var(--radius); padding:18px; box-shadow:var(--shadow-sm); border:1.5px solid var(--gray-light); cursor:pointer; position:relative; overflow:hidden; box-sizing: border-box; }
.ac-label { font-size:0.68rem; font-weight:700; text-transform:uppercase; margin-bottom:4px; }
.ac-title { font-size:1rem; font-weight:700; color:var(--dark); margin-bottom:3px; }
.ac-sub { font-size:0.78rem; color:var(--gray); margin-bottom:14px; }
.ac-btn { display:inline-flex; align-items:center; gap:5px; font-size:0.75rem; font-weight:600; padding:7px 16px; border-radius:var(--radius-full); color:#fff !important; text-decoration:none; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
.ac-prescription .ac-label { color:var(--blue); }
.ac-prescription .ac-btn { background:linear-gradient(135deg,var(--blue),var(--blue-light)); }
.ac-whatsapp .ac-label { color:#25D366; }
.ac-whatsapp .ac-btn { background:linear-gradient(135deg,#128C7E,#25D366); }

/* App components layout modals */
.overlay { position:fixed; inset:0; background:rgba(15,23,42,0.45); backdrop-filter:blur(4px); z-index:99998; opacity:0; pointer-events:none; transition:var(--transition); }
.overlay.active { opacity:1; pointer-events:all; }

.cart-drawer { position:fixed; top:0; right:0; bottom:0; width:min(380px, 95vw); background:#fff; z-index:99999; box-shadow:-8px 0 40px rgba(0,0,0,0.15); display:flex; flex-direction:column; transform:translateX(100%); transition:transform 0.35s cubic-bezier(0.4,0,0.2,1); border-radius:20px 0 0 20px; }
.cart-drawer.open { transform:translateX(0); }
.drawer-header { display:flex; align-items:center; justify-content:space-between; padding:18px 20px; border-bottom:1px solid var(--gray-light); }
.drawer-header h3 { font-size:1.1rem; font-weight:700; margin:0; }
.drawer-close { width:34px; height:34px; border-radius:50%; background:var(--bg); display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--gray); }
.cart-items { flex:1; overflow-y:auto; padding:14px; }
.cart-empty { display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; gap:12px; color:var(--gray); text-align:center; }
.cart-empty i { font-size:3rem; color:var(--gray-light); }
.cart-item { display:flex; gap:12px; padding:12px; background:var(--bg); border-radius:var(--radius-sm); margin-bottom:10px; position:relative; border:1px solid var(--gray-light); }
.ci-img { width:60px; height:60px; background:#fff; border-radius:var(--radius-sm); display:flex; align-items:center; justify-content:center; font-size:1.8rem; border:1px solid var(--gray-light); }
.ci-img img { max-height: 55px; object-fit: contain; }
.ci-info { flex:1; }
.ci-name { font-size:0.85rem; font-weight:600; color: var(--dark); }
.ci-price { font-size:0.9rem; font-weight:700; color:var(--blue); margin-top: 4px; }
.qty-ctrl { display:flex; align-items:center; border:1.5px solid var(--gray-light); border-radius:var(--radius-sm); overflow:hidden; width:fit-content; margin-top: 6px; }
.qty-btn { width:28px; height:28px; background:var(--bg); color:var(--dark); font-size:1rem; font-weight:700; display:flex; align-items:center; justify-content:center; cursor:pointer; }
.qty-val { width:30px; text-align:center; font-size:0.85rem; font-weight:600; background:#fff; }
.ci-remove { position:absolute; top:8px; right:8px; width:22px; height:22px; border-radius:50%; background:#fff; color:var(--gray); font-size:0.7rem; display:flex; align-items:center; justify-content:center; cursor:pointer; border:1px solid var(--gray-light); }
.cart-footer { padding:14px; border-top:1px solid var(--gray-light); background:#fff; }
.cart-totals { margin-bottom:12px; }
.cart-row { display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:5px; }
.cart-row.total { font-size:1.1rem; font-weight:800; border-top:1px dashed var(--gray-light); padding-top:8px; margin-top:4px; color:var(--blue); }
.btn-checkout { width:100%; background:linear-gradient(135deg,var(--blue),var(--blue-light)); color:#fff !important; padding:13px; border-radius:var(--radius-sm); font-size:0.9rem; font-weight:700; border: none; cursor: pointer; display:flex; align-items:center; justify-content:center; gap:8px; }

.modal-wrap { position:fixed; inset:0; z-index:110000; display:flex; align-items:flex-end; justify-content:center; pointer-events:none; }
.modal-wrap.active { pointer-events:all; }
.modal { width:100%; max-width:480px; background:#fff; border-radius:24px 24px 0 0; transform:translateY(100%); transition:transform 0.4s cubic-bezier(0.4,0,0.2,1); box-shadow:0 -8px 40px rgba(0,0,0,0.18); max-height:92vh; overflow-y:auto; box-sizing: border-box; }
.modal-wrap.active .modal { transform:translateY(0); }
.modal-handle { width:40px; height:4px; border-radius:2px; background:var(--gray-light); margin:12px auto 0; }
.modal-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--gray-light); }
.modal-header h3 { font-size:1.1rem; font-weight:700; margin:0; }
.modal-close { width:32px; height:32px; border-radius:50%; background:var(--bg); display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--gray); }
.modal-body { padding:20px; }
.form-group { margin-bottom:14px; }
.form-label { font-size:0.8rem; font-weight:600; color:var(--dark); margin-bottom:6px; display:block; }
.form-input { width:100%; padding:11px 14px; background:var(--bg); border:1.5px solid var(--gray-light); border-radius:var(--radius-sm); font-size:0.88rem; box-sizing: border-box; outline: none; }
.form-input:focus { border-color:var(--blue); background:#fff; }
.order-summary-box { background:var(--bg); border-radius:var(--radius-sm); padding:12px 14px; margin-bottom:16px; border:1.5px solid var(--gray-light); }
.order-summary-box .os-row { display:flex; justify-content:space-between; font-size:0.82rem; padding:4px 0; }
.order-summary-box .os-total { font-size:1rem; font-weight:800; border-top:1px dashed var(--gray-light); padding-top:8px; margin-top:4px; color:var(--blue); }
.modal-footer { padding:14px 20px; border-top:1px solid var(--gray-light); display:flex; flex-direction:column; gap:8px; }
.btn-wa { width:100%; background:linear-gradient(135deg,#128C7E,#25D366); color:#fff !important; padding:12px; border-radius:var(--radius-sm); font-size:0.9rem; font-weight:700; display:flex; align-items:center; justify-content:center; gap:8px; border: none; cursor: pointer; }

.qv-modal { position:fixed; inset:0; z-index:109000; display:flex; align-items:flex-end; pointer-events:none; }
.qv-modal.active { pointer-events:all; }
.qv-inner { width:100%; max-width:480px; margin:0 auto; background:#fff; border-radius:24px 24px 0 0; transform:translateY(100%); transition:transform 0.4s cubic-bezier(0.4,0,0.2,1); box-shadow:0 -8px 40px rgba(0,0,0,0.18); max-height:88vh; overflow-y:auto; }
.qv-modal.active .qv-inner { transform:translateY(0); }
.qv-img-area { background:linear-gradient(135deg,var(--blue-soft),var(--green-soft)); padding:25px; display:flex; align-items:center; justify-content:center; min-height:160px; position:relative; }
.qv-img-area img { max-height: 140px; object-fit: contain; }
.qv-img-area .qv-emoji { font-size:5rem; }
.qv-body { padding:18px 20px; }
.qv-title { font-size:1.2rem; font-weight:700; margin-bottom:4px; }
.qv-price { font-size:1.3rem; font-weight:800; color:var(--blue); margin-bottom:10px; }
.qv-desc { font-size:0.85rem; color:var(--gray); line-height:1.7; margin-bottom:14px; }
.qv-actions { display:flex; gap:10px; padding:0 20px 20px; }
.btn-buynow { flex:1; background:var(--bg); color:var(--blue); border:2px solid var(--blue); padding:12px; border-radius:var(--radius-sm); font-size:0.88rem; font-weight:700; cursor: pointer; }
.qv-add-btn { flex:2; background:linear-gradient(135deg,var(--blue),var(--blue-light)); color:#fff !important; padding:12px; border-radius:var(--radius-sm); font-size:0.9rem; font-weight:700; border: none; cursor: pointer; display:flex; align-items:center; justify-content:center; gap:8px; }

.float-group { position:fixed; bottom:25px; right:16px; z-index:9999; display:flex; flex-direction:column; gap:10px; align-items:flex-end; }
.float-btn { width:52px; height:52px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:var(--shadow-lg); cursor:pointer; position:relative; color: #fff !important; text-decoration: none; }
.float-cart { background: var(--blue); }
.float-wa { background: #25D366; }
.cart-badge-sticky { position:absolute; top:-4px; right:-4px; width:18px; height:18px; border-radius:50%; background:var(--red); color:#fff; font-size:0.65rem; font-weight:700; display:flex; align-items:center; justify-content:center; border:2px solid #fff; }

.toast-container { position:fixed; top:95px; left:50%; transform:translateX(-50%); z-index:210000; display:flex; flex-direction:column; gap:8px; pointer-events:none; min-width:240px; }
.toast { background:#0F172A; color:#fff; padding:12px 18px; border-radius:var(--radius-sm); font-size:0.85rem; font-weight:500; box-shadow:var(--shadow-lg); display:flex; align-items:center; gap:8px; animation:toastIn 0.3s ease; }
.toast.success { background:linear-gradient(135deg,var(--green),var(--green-light)); }
.toast.error { background:linear-gradient(135deg,var(--red),#EF5350); }
@keyframes toastIn { from { opacity:0; transform:translateY(-15px); } to { opacity:1; transform:translateY(0); } }

.mc-rx-box { width: 100%; max-width: 360px; background: #fff; border-radius: 24px; padding: 28px 24px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); text-align: center; position: relative; }
.mc-upload-zone { border: 2px dashed var(--blue); border-radius: var(--radius); padding: 20px; margin-bottom: 16px; cursor: pointer; background: var(--blue-soft); }
.mc-upload-zone i { font-size: 2rem; color: var(--blue); margin-bottom: 8px; display: block; }
.mc-upload-zone p { font-size: 0.75rem; color: var(--blue); font-weight: 500; margin-bottom: 0; }

@media (max-width: 640px) {
  .action-banners { grid-template-columns: 1fr; }
  .hero h1 { font-size: 1.7rem !important; }
}
</style>

<!-- Global Dark Blur Mask overlay -->
<div class="overlay" id="mcGlobalOverlay" onclick="mcCloseAllModals()"></div>

<div class="mc-master-app-wrapper">

  <!-- TOP ROUTING DELIVERY STRIP -->
  <div class="delivery-bar">
    <div class="loc"><i class="fas fa-location-dot"></i> Deliver to: <strong><?php echo esc_html(get_option('woocommerce_store_city', 'Store Settings')); ?></strong></div>
    <div class="free"><i class="fas fa-motorcycle"></i> Safe Express Cash On Delivery Active</div>
  </div>

  <!-- APPLICATION HERO FRAMEWORK -->
  <div class="hero">
    <div class="hero-content">
      <div class="hero-badge"><i class="fas fa-shield-halved"></i> 100% Certified Pharmacy</div>
      <h1>Your <span>Health</span>,<br>Our Priority</h1>
      <p><?php echo esc_html(get_option('mc_hero_subtitle', 'Order medicines online from trusted pharmacy. Genuine products.')); ?></p>
      <div class="hero-btns">
        <button class="btn-primary" onclick="mcOpenCartDrawer()"><i class="fas fa-shopping-basket"></i> View My Basket</button>
        <a href="#mc-rx-section" class="btn-outline"><i class="fas fa-file-medical"></i> Upload Rx</a>
      </div>
    </div>
    <div class="hero-search">
      <i class="fas fa-search" style="color:var(--gray); margin-right:8px;"></i>
      <input type="text" id="mc-app-search-input" placeholder="Search pharmacy items directly..."/>
      <button type="submit" onclick="mcExecuteAppSearch()">Search</button>
    </div>
  </div>

  <!-- STORE CATEGORIES PILLS LIST -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">Store Categories</div></div>
    <div class="cat-scroll">
        <?php
        $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => true, 'number' => 8, 'exclude' => [get_option('default_product_cat')]]);
        $cat_emojis = ['medicines'=>'💊', 'health-care'=>'❤️', 'personal-care'=>'🧴', 'baby-care'=>'👶', 'ayurveda'=>'🌿', 'devices'=>'🩺', 'vitamins'=>'🍊'];
        if (!empty($categories) && !is_wp_error($categories)) {
            foreach ($categories as $cat) {
                $emoji = $cat_emojis[$cat->slug] ?? '🏥';
                echo '<div class="cat-pill" onclick="window.location=\'' . esc_url(get_term_link($cat)) . '\'">';
                echo '<div class="cat-icon">'.$emoji.'</div>';
                echo '<div class="cat-label">'.esc_html($cat->name).'</div></div>';
            }
        }
        ?>
    </div>
  </div>

  <!-- SPECIAL STATIC BANNER MODULE -->
  <div class="section-pad">
    <div class="mc-offer-slider">
        <div class="mc-offer-card mc-offer-card-1">
            <div class="mc-offer-content"><div class="mc-percent">FLAT 20% OFF</div><div class="mc-text">On All Medicines</div><button class="mc-offer-btn" onclick="mcOpenCartDrawer()">Order Now</button></div>
            <div style="font-size:3.5rem;">💊</div>
        </div>
        <div class="mc-offer-card mc-offer-card-2">
            <div class="mc-offer-content"><div class="mc-percent">FREE LOGISTICS</div><div class="mc-text">Orders Above RS <?php echo esc_html(get_option('woocommerce_store_city') ? '500' : '500'); ?></div><button class="mc-offer-btn" onclick="mcOpenCartDrawer()">Shop Now</button></div>
            <div style="font-size:3.5rem;">🏍️</div>
        </div>
    </div>
  </div>

  <!-- BEST SELLING SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">🔥 Best Selling Pharmacy Items</div></div>
    <div class="prod-slider" id="bestSellingContainer"></div>
  </div>

  <!-- ISOLATED BRAND VALUE STRIP -->
  <div class="mc-trust-strip">
    <div class="trust-item"><i class="fas fa-shield-halved"></i><div class="t-title">100% Genuine</div></div>
    <div class="trust-item"><i class="fas fa-rotate-left"></i><div class="t-title">Easy Returns</div></div>
    <div class="trust-item"><i class="fas fa-truck-fast"></i><div class="t-title">Express Delivery</div></div>
  </div>

  <!-- FEATURED PRODUCTS SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">⭐ Featured Healthcare</div></div>
    <div class="prod-slider" id="featuredContainer"></div>
  </div>

  <!-- HERBAL MEDICINE SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">🌿 Organic &amp; Herbal Products</div></div>
    <div class="prod-slider" id="herbalContainer"></div>
  </div>

  <!-- REDIRECT BANNERS INTERACTION -->
  <div id="mc-rx-section" class="action-banners">
    <div class="action-card ac-prescription" onclick="document.getElementById('mcHtmlRxModal').style.display='flex'">
        <div class="ac-label">📋 Prescription</div><div class="ac-title">Upload Rx Medical Sheet</div>
        <div class="ac-btn"><i class="fas fa-upload"></i> Upload Now</div>
    </div>
    <div class="action-card ac-whatsapp">
        <?php $ph = get_option('mc_whatsapp_number', '919876543210'); ?>
        <div class="ac-label">💬 Live Support</div><div class="ac-title">Direct Order on WhatsApp</div>
        <a href="https://wa.me/<?php echo esc_attr($ph); ?>?text=Hi!+I+want+to+order+medicines." target="_blank" class="ac-btn"><i class="fab fa-whatsapp"></i> Chat Now</a>
    </div>
  </div>

  <!-- BABY PRODUCTS SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">👶 Newborn &amp; Baby Care</div></div>
    <div class="prod-slider" id="babyContainer"></div>
  </div>

  <!-- MEDICAL DEVICES SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">🩺 Diagnostic Medical Devices</div></div>
    <div class="prod-slider" id="devicesContainer"></div>
  </div>

  <!-- NEW ARRIVALS SLIDER GRID -->
  <div class="section-pad">
    <div class="section-title-row"><div class="section-title">🆕 Fresh Stock Arrivals</div></div>
    <div class="prod-slider" id="newArrivalsContainer"></div>
  </div>

</div> <!-- Wrapper End -->


<!-- ============================================================
     APP CONTROL COMPONENT DOM STRUCTS (Slide Drawer & Popups)
     ============================================================ -->

<!-- 1. LIVE APP SLIDING BASKET DRAWER -->
<div class="cart-drawer" id="mcCartDrawer">
  <div class="drawer-header">
    <h3>🛒 Selected Basket (<span id="mcCartCount">0</span> Items)</h3>
    <div class="drawer-close" onclick="mcCloseAllModals()"><i class="fas fa-times"></i></div>
  </div>
  <div class="cart-items" id="mcDrawerCartItems">
      <!-- Generated Dynamically via Engine Loop JS -->
  </div>
  <div class="cart-footer" id="mcDrawerFooter" style="display:none;">
    <div class="cart-totals">
      <div class="cart-row"><span>Basket Subtotal</span><span id="mcCartSubtotal">Rs 0</span></div>
      <div class="cart-row"><span>Logistics Fees</span><span style="color:var(--green); font-weight:700;">FREE</span></div>
      <div class="cart-row total"><span>Payable Grand Total</span><span id="mcCartTotal">Rs 0</span></div>
    </div>
    <button class="btn-checkout" onclick="mcOpenCheckoutModal()">
      <i class="fas fa-bolt"></i> Proceed to Checkout Form
    </button>
  </div>
</div>

<!-- 2. APP LIVE QUICK VIEW POPUP SHEET -->
<div class="qv-modal" id="mcQuickViewPopup">
  <div class="qv-inner">
    <div class="qv-img-area">
      <div style="position:absolute; top:14px; right:14px; cursor:pointer; font-size:1.3rem; color:var(--gray);" onclick="mcCloseAllModals()"><i class="fas fa-times-circle"></i></div>
      <div id="mcQvImgSlot"></div>
    </div>
    <div class="qv-body">
      <div class="qv-title" id="mcQvTitle">Product Title</div>
      <div class="qv-price" id="mcQvPrice">Rs 0</div>
      <div class="qv-desc" id="mcQvDesc">Loading verified product clinical summary data structure details...</div>
    </div>
    <div class="qv-actions">
      <button class="qv-add-btn" id="mcQvSubmitBtn" style="width:100%;"><i class="fas fa-cart-plus"></i> Add to Active Basket</button>
    </div>
  </div>
</div>

<!-- 3. SHORT CHECKOUT ACTION FORM SHEET -->
<div class="modal-wrap" id="mcCheckoutModal">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <h3>⚡ Instant Secure Delivery Order</h3>
      <div class="modal-close" onclick="mcCloseAllModals()"><i class="fas fa-times"></i></div>
    </div>
    <div class="modal-body">
      <div class="order-summary-box">
        <div class="os-row os-total"><span>Amount to Pay on Delivery</span><span id="mcFinalAmountField">Rs 0</span></div>
      </div>
      <div class="form-group">
        <label class="form-label">Patient/Buyer Full Name *</label>
        <input class="form-input" type="text" placeholder="Enter complete name" id="co_name"/>
      </div>
      <div class="form-group">
        <label class="form-label">WhatsApp Contact Number *</label>
        <input class="form-input" type="tel" placeholder="Enter active telephone code number" id="co_phone"/>
      </div>
      <div class="form-group">
        <label class="form-label">Full Logistics Home Address *</label>
        <input class="form-input" type="text" placeholder="House/Shop No, Street, Area" id="co_address"/>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-checkout" id="mcSubmitBtnReal" onclick="mcSubmitOrderToDatabase()">
        <i class="fas fa-check-circle"></i> Confirm Instant Cash on Delivery
      </button>
      <button class="btn-wa" onclick="mcRedirectOrderToWhatsApp()">
        <i class="fab fa-whatsapp"></i> Dispatch Order Via WhatsApp Chat
      </button>
    </div>
  </div>
</div>

<!-- 4. MANUAL RX UPLOAD POPUP -->
<div id="mcHtmlRxModal" style="display:none;position:fixed;inset:0;z-index:220000;align-items:center;justify-content:center;padding:16px;background:rgba(15,23,42,0.5);">
    <div class="mc-rx-box">
        <div style="position:absolute;top:14px;right:14px;cursor:pointer;color:var(--gray);" onclick="document.getElementById('mcHtmlRxModal').style.display='none'"><i class="fas fa-times"></i></div>
        <div style="font-size:3rem; margin-bottom:10px; text-align:center;">📋</div>
        <h3 style="text-align:center; margin-bottom:5px;">Upload Prescription Form</h3>
        <p style="text-align:center; font-size:0.8rem; color:var(--gray); margin-bottom:15px;">Our verification specialists will evaluate documentation.</p>
        <div class="mc-upload-zone" onclick="mcAppToast('Select document sheet photo from file library')">
            <i class="fas fa-cloud-arrow-up"></i><p>Select File or Snap Image</p>
        </div>
        <input type="tel" placeholder="Active WhatsApp Contact" class="mc-form-input" style="margin-bottom:12px;"/>
        <button class="btn-primary" style="width:100%; justify-content:center; border:none;" onclick="document.getElementById('mcHtmlRxModal').style.display='none'; mcAppToast('Prescription submitted for manual check!','success')">Submit for Pharmacy Verification</button>
    </div>
</div>

<!-- STICKY OVERLAY NAVIGATION BADGE INTERACTIVE HOOKS -->
<div class="float-group">
  <div class="float-btn float-cart" onclick="mcOpenCartDrawer()">
    <i class="fas fa-shopping-basket"></i>
    <div class="cart-badge-sticky" id="mcStickyBadgeCount">0</div>
  </div>
  <a href="https://wa.me/<?php echo esc_attr($ph); ?>" target="_blank" class="float-btn float-wa"><i class="fab fa-whatsapp"></i></a>
</div>

<div class="toast-container" id="mcToastContainer"></div>

<!-- ============================================================
     APPLICATION INTERACTIVE RUNTIME ENGINE (JAVASCRIPT)
     ============================================================ -->
<script>
const mcStoreDatabase = <?php echo json_encode($mc_js_products); ?>;
const mcWaTargetNumber = "<?php echo esc_js(get_option('mc_whatsapp_number', '919876543210')); ?>";
let mcAppCartState = {};

function mcAppToast(msg, type='success') {
    const container = document.getElementById('mcToastContainer');
    if(!container) return;
    const t = document.createElement('div');
    t.className = 'toast ' + type;
    t.innerHTML = `<i class="fas fa-info-circle"></i> ${msg}`;
    container.appendChild(t);
    setTimeout(() => t.remove(), 2500);
}

function mcRenderSliderCollection(containerId, productDataset) {
    const el = document.getElementById(containerId);
    if (!el) return;
    if(!productDataset || productDataset.length === 0) {
        el.innerHTML = '<div style="font-size:0.8rem;color:var(--gray);padding:10px;">No active entries mapped inside database.</div>';
        return;
    }
    el.innerHTML = productDataset.map(p => `
        <div class="prod-card" onclick="mcTriggerQuickView(${p.id})">
            <div class="prod-badge">${p.disc}</div>
            <div class="prod-img">
                ${p.img ? `<img src="${p.img}" alt="${p.name}" />` : `<div class="prod-emoji">💊</div>`}
            </div>
            <div class="prod-name">${p.name}</div>
            <div class="prod-sub">${p.sub}</div>
            ${p.reviews > 0 ? `<div class="prod-stars">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-stroke"></i>
                <span>(${p.reviews})</span>
            </div>` : ''}
            <div class="prod-price">
                <span class="price">Rs ${p.price}</span>
                <span class="old">Rs ${p.old}</span>
            </div>
            <button class="btn-add" onclick="event.stopPropagation(); mcInlineBasketPush(${p.id});">
                <i class="fas fa-cart-plus"></i> Add to Basket
            </button>
            <div class="quick-view"><i class="fas fa-eye"></i> Quick View</div>
        </div>
    `).join('');
}

function mcFindProductAcrossDatabase(id) {
    for (let section in mcStoreDatabase) {
        let match = mcStoreDatabase[section].find(p => p.id == id);
        if (match) return match;
    }
    return null;
}

function mcTriggerQuickView(id) {
    mcCloseAllModals();
    const p = mcFindProductAcrossDatabase(id);
    if(!p) return;

    document.getElementById('mcQvTitle').textContent = p.name;
    document.getElementById('mcQvPrice').textContent = 'Rs ' + p.price;
    document.getElementById('mcQvDesc').textContent = p.desc;

    const slot = document.getElementById('mcQvImgSlot');
    slot.innerHTML = p.img ? `<img src="${p.img}" alt="${p.name}" />` : `<div class="qv-emoji">💊</div>`;

    document.getElementById('mcQvSubmitBtn').onclick = function() {
        mcInlineBasketPush(p.id);
    };

    document.getElementById('mcQuickViewPopup').classList.add('active');
    document.getElementById('mcGlobalOverlay').classList.add('active');
}

function mcInlineBasketPush(id) {
    const p = mcFindProductAcrossDatabase(id);
    if(!p) return;

    if(mcAppCartState[id]) {
        mcAppCartState[id].qty += 1;
    } else {
        mcAppCartState[id] = { ...p, qty: 1 };
    }
    mcRefreshCartStateUI();
    mcAppToast(`${p.name} added to active basket!`, 'success');
    mcOpenCartDrawer();
}

function mcUpdateQtyState(id, change) {
    if(!mcAppCartState[id]) return;
    mcAppCartState[id].qty += change;
    if(mcAppCartState[id].qty <= 0) delete mcAppCartState[id];
    mcRefreshCartStateUI();
}

function mcRefreshCartStateUI() {
    const container = document.getElementById('mcDrawerCartItems');
    if (!container) return; // guard: drawer not yet in DOM
    const items = Object.values(mcAppCartState);
    let count = 0; let subtotal = 0;

    if(items.length === 0) {
        container.innerHTML = `<div class="cart-empty"><i class="fas fa-shopping-basket"></i><p>Your delivery basket is empty.</p></div>`;
        document.getElementById('mcDrawerFooter').style.display = 'none';
        document.getElementById('mcCartCount').textContent = '0';
        document.getElementById('mcStickyBadgeCount').textContent = '0';
        return;
    }

    container.innerHTML = items.map(i => {
        count += i.qty;
        subtotal += (i.price * i.qty);
        return `
            <div class="cart-item">
                <div class="ci-img">${i.img ? `<img src="${i.img}"/>` : '💊'}</div>
                <div class="ci-info">
                    <div class="ci-name">${i.name}</div>
                    <div class="ci-price">Rs ${i.price * i.qty}</div>
                    <div class="qty-ctrl">
                        <div class="qty-btn" onclick="mcUpdateQtyState(${i.id}, -1)">−</div>
                        <div class="qty-val">${i.qty}</div>
                        <div class="qty-btn" onclick="mcUpdateQtyState(${i.id}, 1)">+</div>
                    </div>
                </div>
                <div class="ci-remove" onclick="mcUpdateQtyState(${i.id}, -${i.qty})"><i class="fas fa-times"></i></div>
            </div>
        `;
    }).join('');

    document.getElementById('mcCartSubtotal').textContent = 'Rs ' + subtotal;
    document.getElementById('mcCartTotal').textContent = 'Rs ' + subtotal;
    document.getElementById('mcFinalAmountField').textContent = 'Rs ' + subtotal;
    document.getElementById('mcCartCount').textContent = count;
    document.getElementById('mcStickyBadgeCount').textContent = count;
    document.getElementById('mcDrawerFooter').style.display = 'block';
}

function mcOpenCartDrawer() {
    mcCloseAllModals();
    document.getElementById('mcCartDrawer').classList.add('open');
    document.getElementById('mcGlobalOverlay').classList.add('active');
}

function mcOpenCheckoutModal() {
    mcCloseAllModals();
    document.getElementById('mcCheckoutModal').classList.add('active');
    document.getElementById('mcGlobalOverlay').classList.add('active');
}

function mcCloseAllModals() {
    ['mcCartDrawer','mcCheckoutModal','mcQuickViewPopup'].forEach(id => {
        const el = document.getElementById(id);
        if (el) { el.classList.remove('open'); el.classList.remove('active'); }
    });
    const ov = document.getElementById('mcGlobalOverlay');
    if (ov) ov.classList.remove('active');
}

// 🚀 The Real WooCommerce AJAX Checkout Processor
async function mcSubmitOrderToDatabase() {
    const name  = document.getElementById('co_name').value.trim();
    const phone = document.getElementById('co_phone').value.trim();
    const addr  = document.getElementById('co_address').value.trim();

    if(!name || !phone || !addr) {
        mcAppToast('Please fill all mandatory fields!', 'error');
        return;
    }
    
    mcAppToast('Processing your order...', 'success');
    const btn = document.getElementById('mcSubmitBtnReal');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing Order...';
    btn.style.pointerEvents = 'none';
    
    const formData = new FormData();
    formData.append('action',    'mc_place_order');                    // WP-AJAX action
    formData.append('security',  '<?php echo wp_create_nonce("mc_order_nonce"); ?>');
    formData.append('name',      name);
    formData.append('phone',     phone);
    formData.append('address',   addr);
    formData.append('cart_data', JSON.stringify(Object.values(mcAppCartState)));
    try {
        const response = await fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if(result.success) {
            mcCloseAllModals();
            mcAppCartState = {};
            mcRefreshCartStateUI();
            document.getElementById('mcStickyBadgeCount').textContent = '0';
            alert(`✅ Order Placed Successfully!\n\nOrder ID: #${result.data.order_id}\nThank you, ${name}.\nYou will be contacted shortly to confirm delivery.`);
        } else {
            mcAppToast('Error: ' + (result.data ? result.data.message : 'Unknown error'), 'error');
        }
    } catch(e) {
        mcAppToast('Network error. Please try WhatsApp order instead.', 'error');
    } finally {
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Confirm Instant Cash on Delivery';
        btn.style.pointerEvents = 'auto';
    }
}

function mcRedirectOrderToWhatsApp() {
    const name = document.getElementById('co_name').value.trim() || 'Customer';
    const addr = document.getElementById('co_address').value.trim() || 'Address';
    const items = Object.values(mcAppCartState).map(i => `${i.name} x${i.qty}`).join('%0A');
    const total = document.getElementById('mcFinalAmountField').textContent;
    
    const msg = `Hello! New order request details:%0A%0AItems:%0A${items}%0A%0ATotal Amount: ${total}%0AName: ${name}%0AAddress: ${addr}`;
    window.open(`https://wa.me/${mcWaTargetNumber}?text=${msg}`, '_blank');
    mcCloseAllModals();
}

function mcExecuteAppSearch() {
    const val = document.getElementById('mc-app-search-input').value.trim();
    if(val) { window.location.href = "<?php echo esc_url(wc_get_page_permalink('shop')); ?>?s=" + encodeURIComponent(val) + "&post_type=product"; }
}

// Initialize product collections
document.addEventListener('DOMContentLoaded', () => {
    mcRenderSliderCollection('bestSellingContainer', mcStoreDatabase.bestSelling);
    mcRenderSliderCollection('featuredContainer', mcStoreDatabase.featured);
    mcRenderSliderCollection('herbalContainer', mcStoreDatabase.herbal);
    mcRenderSliderCollection('babyContainer', mcStoreDatabase.baby);
    mcRenderSliderCollection('devicesContainer', mcStoreDatabase.devices);
    mcRenderSliderCollection('newArrivalsContainer', mcStoreDatabase.newArrivals);
    mcRefreshCartStateUI();
});
</script>

<?php 
get_footer(); // Load theme footer architecture 
?>